import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Team Members (separate from auth users)
export const teamMembers = pgTable("team_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email"),
});

export const insertTeamMemberSchema = createInsertSchema(teamMembers).omit({
  id: true,
});

export type InsertTeamMember = z.infer<typeof insertTeamMemberSchema>;
export type TeamMember = typeof teamMembers.$inferSelect;

// Project Members (join table)
export const projectMembers = pgTable("project_members", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  projectId: varchar("project_id").notNull(),
  memberId: varchar("member_id").notNull(),
});

export const insertProjectMemberSchema = createInsertSchema(projectMembers).omit({
  id: true,
});

export type InsertProjectMember = z.infer<typeof insertProjectMemberSchema>;
export type ProjectMember = typeof projectMembers.$inferSelect;

// Projects
export const projects = pgTable("projects", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  createdById: varchar("created_by_id"),
});

export const insertProjectSchema = createInsertSchema(projects).omit({
  id: true,
});

export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;

// Sections
export const sections = pgTable("sections", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  projectId: varchar("project_id").notNull(),
  order: integer("order").notNull().default(0),
});

export const insertSectionSchema = createInsertSchema(sections).omit({
  id: true,
});

export type InsertSection = z.infer<typeof insertSectionSchema>;
export type Section = typeof sections.$inferSelect;

// Tasks
export const taskStatusEnum = z.enum(["todo", "in_progress", "complete"]);
export const taskPriorityEnum = z.enum(["low", "medium", "high", "critical"]);

export type TaskStatus = z.infer<typeof taskStatusEnum>;
export type TaskPriority = z.infer<typeof taskPriorityEnum>;

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  status: text("status").$type<TaskStatus>(),
  priority: text("priority").$type<TaskPriority>(),
  startDate: text("start_date"),
  dueDate: text("due_date"),
  assignedMemberId: varchar("assigned_member_id"),
  createdById: varchar("created_by_id"),
  sectionId: varchar("section_id").notNull(),
  projectId: varchar("project_id").notNull(),
  order: integer("order").notNull().default(0),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

// Status Reports
export const statusReportStatusEnum = z.enum(["On Track", "At Risk", "Off Track", "On Hold", "Complete"]);
export type StatusReportStatus = z.infer<typeof statusReportStatusEnum>;

export const statusReports = pgTable("status_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  status: text("status").$type<StatusReportStatus>().notNull(),
  projectId: varchar("project_id").notNull(),
  createdById: varchar("created_by_id"),
  createdAt: text("created_at").notNull(),
});

export const insertStatusReportSchema = createInsertSchema(statusReports).omit({
  id: true,
});

export type InsertStatusReport = z.infer<typeof insertStatusReportSchema>;
export type StatusReport = typeof statusReports.$inferSelect;

// Activity Logs
export const activityActionEnum = z.enum(["created", "updated", "deleted"]);
export const activityEntityTypeEnum = z.enum(["project", "task", "section", "status_report"]);

export type ActivityAction = z.infer<typeof activityActionEnum>;
export type ActivityEntityType = z.infer<typeof activityEntityTypeEnum>;

export const activityLogs = pgTable("activity_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  entityType: text("entity_type").$type<ActivityEntityType>().notNull(),
  entityId: varchar("entity_id").notNull(),
  projectId: varchar("project_id").notNull(),
  action: text("action").$type<ActivityAction>().notNull(),
  field: text("field"),
  oldValue: text("old_value"),
  newValue: text("new_value"),
  performedById: varchar("performed_by_id"),
  timestamp: text("timestamp").notNull(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
});

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

// Extended activity log with performer name
export type ActivityLogWithPerformer = ActivityLog & {
  performerName?: string;
};

// Extended types for frontend
export type SectionWithTasks = Section & {
  tasks: Task[];
};

export type ProjectWithSections = Project & {
  sections: SectionWithTasks[];
  taskCount: number;
};
