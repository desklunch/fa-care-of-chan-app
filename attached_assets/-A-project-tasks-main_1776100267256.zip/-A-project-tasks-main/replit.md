# TaskFlow - Project Management Application

## Development Rules

### User Guide Maintenance
**IMPORTANT:** When making functional changes to the application that affect how users interact with features, you MUST update the User Guide component (`client/src/components/user-guide.tsx`) to reflect those changes. This includes:
- Adding new features or capabilities
- Changing how existing features work
- Adding or modifying keyboard shortcuts
- Changing UI elements or workflows
- Adding new task properties or project features

## Overview
TaskFlow is a modern project management application built with React and Express. It allows users to create projects, organize tasks into sections, and manage their workflow with drag-and-drop functionality.

## Recent Changes
- **Dec 12, 2025**: Initial implementation of the project management app with full CRUD for projects, sections, and tasks, plus drag-and-drop reordering.

## Key Features
- Create, edit, and delete projects
- Organize tasks into sections within projects
- Drag-and-drop to reorder sections
- Drag-and-drop to reorder tasks within sections
- Drag-and-drop to move tasks between sections
- Task properties: name (required), status, priority, start date, due date, description
- Dark mode support
- Responsive sidebar navigation

## Project Architecture

### Frontend (React + Vite)
- **client/src/App.tsx** - Main application with routing and project management
- **client/src/components/** - Reusable UI components
  - `app-sidebar.tsx` - Project list sidebar
  - `task-grid.tsx` - Main task data grid with drag-and-drop
  - `sortable-section.tsx` / `sortable-task.tsx` - DnD wrapper components
  - `task-row.tsx` - Individual task row display
  - `project-dialog.tsx` / `section-dialog.tsx` / `task-dialog.tsx` - Modal forms
  - `theme-toggle.tsx` - Dark mode toggle
- **client/src/pages/** - Page components
  - `home.tsx` - Welcome page
  - `project-detail.tsx` - Project view with task grid

### Backend (Express)
- **server/routes.ts** - API endpoints for all CRUD operations
- **server/storage.ts** - In-memory storage layer

### Shared
- **shared/schema.ts** - Data models and Zod validation schemas

## API Endpoints
- `GET /api/projects` - List all projects
- `POST /api/projects` - Create project
- `GET /api/projects/:id` - Get project
- `PATCH /api/projects/:id` - Update project
- `DELETE /api/projects/:id` - Delete project
- `GET /api/projects/:projectId/sections` - Get sections with tasks
- `POST /api/projects/:projectId/sections` - Create section
- `PATCH /api/sections/:id` - Update section
- `DELETE /api/sections/:id` - Delete section
- `POST /api/projects/:projectId/sections/reorder` - Reorder sections
- `POST /api/projects/:projectId/tasks` - Create task
- `PATCH /api/tasks/:id` - Update task
- `DELETE /api/tasks/:id` - Delete task
- `POST /api/sections/:sectionId/tasks/reorder` - Reorder tasks
- `POST /api/tasks/:taskId/move` - Move task between sections

## Technologies
- React 18
- TypeScript
- TanStack Query (React Query)
- @dnd-kit for drag-and-drop
- Tailwind CSS
- shadcn/ui components
- Express.js
- Zod for validation
- wouter for routing
