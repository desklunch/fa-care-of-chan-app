import { useState, useRef, useEffect } from "react";
import { GripVertical, Trash2, CalendarIcon, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import type { Task, TeamMember } from "@shared/schema";
import { format, parse, parseISO } from "date-fns";
import { cn } from "@/lib/utils";

interface TaskRowProps {
  task: Task;
  dragHandleProps: React.HTMLAttributes<HTMLElement>;
  onUpdate: (updates: Partial<Task>) => void;
  onDelete: () => void;
  onOpenDetail?: () => void;
  isOverlay?: boolean;
  projectMembers?: TeamMember[];
}

const statusColors: Record<string, string> = {
  todo: "bg-muted text-muted-foreground",
  in_progress: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  complete: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
};

const statusLabels: Record<string, string> = {
  todo: "To Do",
  in_progress: "In Progress",
  complete: "Complete",
};

const priorityColors: Record<string, string> = {
  low: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  high: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  critical: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

const priorityLabels: Record<string, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
};

function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return "";
  try {
    return format(parseISO(dateString), "MMM d, yyyy");
  } catch {
    return dateString;
  }
}

export function TaskRow({
  task,
  dragHandleProps,
  onUpdate,
  onDelete,
  onOpenDetail,
  isOverlay = false,
  projectMembers = [],
}: TaskRowProps) {
  const [editingName, setEditingName] = useState(false);
  const [nameValue, setNameValue] = useState(task.name);
  const [editingDescription, setEditingDescription] = useState(false);
  const [descriptionValue, setDescriptionValue] = useState(task.description || "");
  const nameInputRef = useRef<HTMLInputElement>(null);
  const descriptionInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setNameValue(task.name);
    setDescriptionValue(task.description || "");
  }, [task.name, task.description]);

  useEffect(() => {
    if (editingName && nameInputRef.current) {
      nameInputRef.current.focus();
      nameInputRef.current.select();
    }
  }, [editingName]);

  useEffect(() => {
    if (editingDescription && descriptionInputRef.current) {
      descriptionInputRef.current.focus();
      descriptionInputRef.current.select();
    }
  }, [editingDescription]);

  const handleNameSubmit = () => {
    if (nameValue.trim() && nameValue !== task.name) {
      onUpdate({ name: nameValue.trim() });
    } else {
      setNameValue(task.name);
    }
    setEditingName(false);
  };

  const handleDescriptionSubmit = () => {
    if (descriptionValue !== task.description) {
      onUpdate({ description: descriptionValue });
    }
    setEditingDescription(false);
  };

  const handleStatusChange = (value: string) => {
    if (value === "none") {
      onUpdate({ status: null });
    } else {
      onUpdate({ status: value as Task["status"] });
    }
  };

  const handlePriorityChange = (value: string) => {
    if (value === "none") {
      onUpdate({ priority: null });
    } else {
      onUpdate({ priority: value as Task["priority"] });
    }
  };

  const handleAssigneeChange = (value: string) => {
    if (value === "none") {
      onUpdate({ assignedMemberId: null });
    } else {
      onUpdate({ assignedMemberId: value });
    }
  };

  const getAssigneeName = () => {
    if (!task.assignedMemberId) return null;
    return projectMembers.find((m) => m.id === task.assignedMemberId)?.name || "Unknown";
  };

  const handleStartDateChange = (date: Date | undefined) => {
    onUpdate({ startDate: date ? format(date, "yyyy-MM-dd") : null });
  };

  const handleDueDateChange = (date: Date | undefined) => {
    onUpdate({ dueDate: date ? format(date, "yyyy-MM-dd") : null });
  };

  if (isOverlay) {
    return (
      <>
        <td className="px-2 py-3 border-r border-border">
          <button
            {...dragHandleProps}
            className="flex items-center justify-center w-6 h-6 rounded cursor-grab active:cursor-grabbing hover-elevate"
            data-testid={`overlay-drag-handle-${task.id}`}
          >
            <GripVertical className="h-4 w-4 text-muted-foreground" />
          </button>
        </td>
        <td className="px-4 py-3 border-r border-border">
          <span className="text-[15px] font-normal" data-testid={`overlay-task-name-${task.id}`}>
            {task.name}
          </span>
        </td>
        <td className="px-4 py-3 border-r border-border">
          {task.status ? (
            <Badge variant="secondary" className={`${statusColors[task.status]} no-default-active-elevate`}>
              {statusLabels[task.status]}
            </Badge>
          ) : (
            <span className="text-sm text-muted-foreground/50">-</span>
          )}
        </td>
        <td className="px-4 py-3 border-r border-border">
          <span className="text-sm text-foreground">
            {task.startDate ? formatDate(task.startDate) : <span className="text-muted-foreground/50">-</span>}
          </span>
        </td>
        <td className="px-4 py-3 border-r border-border">
          <span className="text-sm text-foreground">
            {task.dueDate ? formatDate(task.dueDate) : <span className="text-muted-foreground/50">-</span>}
          </span>
        </td>
        <td className="px-4 py-3 border-r border-border">
          {task.priority ? (
            <Badge variant="secondary" className={`${priorityColors[task.priority]} no-default-active-elevate`}>
              {priorityLabels[task.priority]}
            </Badge>
          ) : (
            <span className="text-sm text-muted-foreground/50">-</span>
          )}
        </td>
        <td className="px-4 py-3 border-r border-border">
          <span className="text-sm text-foreground">
            {getAssigneeName() || <span className="text-muted-foreground/50">-</span>}
          </span>
        </td>
        <td className="px-4 py-3 border-r border-border">
          <span className="text-sm text-muted-foreground truncate max-w-[200px] inline-block">
            {task.description || <span className="text-muted-foreground/50">-</span>}
          </span>
        </td>
        <td className="px-4 py-3" />
      </>
    );
  }

  const handleNameClick = () => {
    if (window.innerWidth < 768 && onOpenDetail) {
      onOpenDetail();
    } else {
      setEditingName(true);
    }
  };

  return (
    <>
      <td className="hidden md:table-cell px-2 py-3 border-r border-border">
        <button
          {...dragHandleProps}
          className="flex items-center justify-center w-6 h-6 rounded cursor-grab active:cursor-grabbing hover-elevate"
          data-testid={`drag-handle-task-${task.id}`}
        >
          <GripVertical className="h-4 w-4 text-muted-foreground" />
        </button>
      </td>
      <td className="px-4 py-3 md:border-r border-border group">
        <div className="flex items-center justify-between gap-2">
          {editingName ? (
            <Input
              ref={nameInputRef}
              value={nameValue}
              onChange={(e) => setNameValue(e.target.value)}
              onBlur={handleNameSubmit}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleNameSubmit();
                if (e.key === "Escape") {
                  setNameValue(task.name);
                  setEditingName(false);
                }
              }}
              className="h-8 flex-1 text-[15px]"
              data-testid={`input-inline-task-name-${task.id}`}
            />
          ) : (
            <span
              className="text-[15px] font-normal cursor-pointer hover:bg-muted/50 px-2 py-1 -mx-2 rounded flex-1"
              onClick={handleNameClick}
              data-testid={`text-task-name-${task.id}`}
            >
              {task.name}
            </span>
          )}
          {onOpenDetail && (
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-muted-foreground invisible group-hover:visible flex-shrink-0 hidden md:flex"
              onClick={(e) => {
                e.stopPropagation();
                onOpenDetail();
              }}
              data-testid={`button-detail-task-${task.id}`}
            >
              <ExternalLink className="h-3 w-3" />
            </Button>
          )}
        </div>
      </td>
      <td className="hidden md:table-cell px-4 py-3 border-r border-border">
        <Select value={task.status || "none"} onValueChange={handleStatusChange}>
          <SelectTrigger 
            className="h-8 w-full border-0 bg-transparent hover:bg-muted/50 focus:ring-0"
            data-testid={`select-inline-status-${task.id}`}
          >
            {task.status ? (
              <Badge
                variant="secondary"
                className={`${statusColors[task.status]} no-default-active-elevate pointer-events-none`}
              >
                {statusLabels[task.status]}
              </Badge>
            ) : (
              <span className="text-sm text-muted-foreground/50">-</span>
            )}
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">None</SelectItem>
            <SelectItem value="todo">To Do</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="complete">Complete</SelectItem>
          </SelectContent>
        </Select>
      </td>
      <td className="hidden md:table-cell px-4 py-3 border-r border-border">
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              className={cn(
                "h-8 w-full px-2 justify-start text-left font-normal hover:bg-muted/50",
                !task.startDate && "text-muted-foreground/50"
              )}
              data-testid={`button-inline-start-date-${task.id}`}
            >
              {task.startDate ? (
                <span className="text-sm">{formatDate(task.startDate)}</span>
              ) : (
                <span className="text-sm">-</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={task.startDate ? parseISO(task.startDate) : undefined}
              onSelect={handleStartDateChange}
              initialFocus
            />
            {task.startDate && (
              <div className="p-2 border-t">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  onClick={() => handleStartDateChange(undefined)}
                >
                  Clear date
                </Button>
              </div>
            )}
          </PopoverContent>
        </Popover>
      </td>
      <td className="hidden md:table-cell px-4 py-3 border-r border-border">
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              className={cn(
                "h-8 w-full px-2 justify-start text-left font-normal hover:bg-muted/50",
                !task.dueDate && "text-muted-foreground/50"
              )}
              data-testid={`button-inline-due-date-${task.id}`}
            >
              {task.dueDate ? (
                <span className="text-sm">{formatDate(task.dueDate)}</span>
              ) : (
                <span className="text-sm">-</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={task.dueDate ? parseISO(task.dueDate) : undefined}
              onSelect={handleDueDateChange}
              initialFocus
            />
            {task.dueDate && (
              <div className="p-2 border-t">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                  onClick={() => handleDueDateChange(undefined)}
                >
                  Clear date
                </Button>
              </div>
            )}
          </PopoverContent>
        </Popover>
      </td>
      <td className="hidden md:table-cell px-4 py-3 border-r border-border">
        <Select value={task.priority || "none"} onValueChange={handlePriorityChange}>
          <SelectTrigger 
            className="h-8 w-full border-0 bg-transparent hover:bg-muted/50 focus:ring-0"
            data-testid={`select-inline-priority-${task.id}`}
          >
            {task.priority ? (
              <Badge
                variant="secondary"
                className={`${priorityColors[task.priority]} no-default-active-elevate pointer-events-none`}
              >
                {priorityLabels[task.priority]}
              </Badge>
            ) : (
              <span className="text-sm text-muted-foreground/50">-</span>
            )}
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">None</SelectItem>
            <SelectItem value="low">Low</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="high">High</SelectItem>
            <SelectItem value="critical">Critical</SelectItem>
          </SelectContent>
        </Select>
      </td>
      <td className="hidden md:table-cell px-4 py-3 border-r border-border">
        <Select value={task.assignedMemberId || "none"} onValueChange={handleAssigneeChange}>
          <SelectTrigger 
            className="h-8 w-full border-0 bg-transparent hover:bg-muted/50 focus:ring-0"
            data-testid={`select-inline-assignee-${task.id}`}
          >
            {task.assignedMemberId && getAssigneeName() ? (
              <span className="text-sm truncate">{getAssigneeName()}</span>
            ) : (
              <span className="text-sm text-muted-foreground/50">-</span>
            )}
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Unassigned</SelectItem>
            {projectMembers.map((member) => (
              <SelectItem key={member.id} value={member.id}>
                {member.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </td>
      <td className="hidden md:table-cell px-4 py-3 border-r border-border">
        {editingDescription ? (
          <Input
            ref={descriptionInputRef}
            value={descriptionValue}
            onChange={(e) => setDescriptionValue(e.target.value)}
            onBlur={handleDescriptionSubmit}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleDescriptionSubmit();
              if (e.key === "Escape") {
                setDescriptionValue(task.description || "");
                setEditingDescription(false);
              }
            }}
            className="h-8 w-full text-sm"
            placeholder="Add description..."
            data-testid={`input-inline-description-${task.id}`}
          />
        ) : (
          <span
            className="text-sm text-muted-foreground truncate w-full block cursor-pointer hover:bg-muted/50 px-2 py-1 -mx-2 rounded"
            onClick={() => setEditingDescription(true)}
            title={task.description || "Click to add description"}
            data-testid={`text-task-description-${task.id}`}
          >
            {task.description || <span className="text-muted-foreground/50">-</span>}
          </span>
        )}
      </td>
      <td className="hidden md:table-cell px-4 py-3">
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6 text-muted-foreground hover:text-destructive"
          onClick={onDelete}
          data-testid={`button-delete-task-${task.id}`}
        >
          <Trash2 className="h-3 w-3" />
        </Button>
      </td>
    </>
  );
}
