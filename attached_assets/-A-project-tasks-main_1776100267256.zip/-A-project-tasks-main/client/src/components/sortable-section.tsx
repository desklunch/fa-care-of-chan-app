import { useSortable } from "@dnd-kit/sortable";
import type { SectionWithTasks } from "@shared/schema";

interface SortableSectionProps {
  section: SectionWithTasks;
  children: (
    dragHandleProps: React.HTMLAttributes<HTMLElement>,
    setNodeRef: (element: HTMLElement | null) => void
  ) => React.ReactNode;
  showDropIndicator?: "before" | "after" | null;
}

export function SortableSection({ section, children, showDropIndicator }: SortableSectionProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    isDragging,
  } = useSortable({ 
    id: section.id,
    animateLayoutChanges: () => false,
  });

  return (
    <>
      {showDropIndicator === "before" && (
        <tr>
          <td colSpan={8} className="p-0 h-[3px] bg-primary" />
        </tr>
      )}
      {children({ ...listeners, ...attributes, style: { opacity: isDragging ? 0.4 : 1 } }, setNodeRef)}
      {showDropIndicator === "after" && (
        <tr>
          <td colSpan={8} className="p-0 h-[3px] bg-primary" />
        </tr>
      )}
    </>
  );
}
