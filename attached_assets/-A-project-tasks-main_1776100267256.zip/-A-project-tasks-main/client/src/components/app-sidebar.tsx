import { Plus, FolderKanban, Loader2, Users } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Project } from "@shared/schema";

interface AppSidebarProps {
  projects: Project[];
  taskCounts: Record<string, number>;
  isLoading: boolean;
  onCreateProject: () => void;
}

export function AppSidebar({
  projects,
  taskCounts,
  isLoading,
  onCreateProject,
}: AppSidebarProps) {
  const [location] = useLocation();

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <div className="flex items-center gap-2">
          <FolderKanban className="h-6 w-6 text-primary" />
          <span className="text-lg font-semibold">TaskFlow</span>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <div className="flex items-center justify-between gap-2 px-2">
            <SidebarGroupLabel className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Projects
            </SidebarGroupLabel>
            <Button
              variant="ghost"
              size="icon"
              onClick={onCreateProject}
              data-testid="button-create-project"
              className="h-6 w-6"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          <SidebarGroupContent>
            <SidebarMenu>
              {isLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
                </div>
              ) : projects.length === 0 ? (
                <div className="px-4 py-8 text-center">
                  <p className="text-sm text-muted-foreground">
                    No projects yet
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onCreateProject}
                    className="mt-2"
                    data-testid="button-create-first-project"
                  >
                    Create your first project
                  </Button>
                </div>
              ) : (
                projects.map((project) => {
                  const isActive = location === `/projects/${project.id}`;
                  const count = taskCounts[project.id] || 0;
                  return (
                    <SidebarMenuItem key={project.id}>
                      <SidebarMenuButton
                        asChild
                        isActive={isActive}
                        className="justify-between"
                      >
                        <Link
                          href={`/projects/${project.id}`}
                          data-testid={`link-project-${project.id}`}
                        >
                          <span className="truncate">{project.name}</span>
                          {count > 0 && (
                            <Badge
                              variant="secondary"
                              className="ml-auto text-xs"
                            >
                              {count}
                            </Badge>
                          )}
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  asChild
                  isActive={location === "/team"}
                >
                  <Link href="/team" data-testid="link-team-members">
                    <Users className="h-4 w-4" />
                    <span>Team Members</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
