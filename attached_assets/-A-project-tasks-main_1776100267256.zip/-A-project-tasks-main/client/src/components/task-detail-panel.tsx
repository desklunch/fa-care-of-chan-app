import { useState, useRef, useEffect } from "react";
import { X, CalendarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import type { Task, TeamMember } from "@shared/schema";
import { format, parseISO } from "date-fns";
import { cn } from "@/lib/utils";

interface TaskDetailPanelProps {
  task: Task;
  projectMembers: TeamMember[];
  onUpdate: (updates: Partial<Task>) => void;
  onClose: () => void;
}

const statusColors: Record<string, string> = {
  todo: "bg-muted text-muted-foreground",
  in_progress: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  complete: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
};

const statusLabels: Record<string, string> = {
  todo: "To Do",
  in_progress: "In Progress",
  complete: "Complete",
};

const priorityColors: Record<string, string> = {
  low: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  high: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  critical: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

const priorityLabels: Record<string, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
};

function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return "";
  try {
    return format(parseISO(dateString), "MMM d, yyyy");
  } catch {
    return dateString;
  }
}

export function TaskDetailPanel({
  task,
  projectMembers,
  onUpdate,
  onClose,
}: TaskDetailPanelProps) {
  const [editingName, setEditingName] = useState(false);
  const [nameValue, setNameValue] = useState(task.name);
  const [editingDescription, setEditingDescription] = useState(false);
  const [descriptionValue, setDescriptionValue] = useState(task.description || "");
  const nameInputRef = useRef<HTMLInputElement>(null);
  const descriptionRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setNameValue(task.name);
    setDescriptionValue(task.description || "");
  }, [task.name, task.description]);

  useEffect(() => {
    if (editingName && nameInputRef.current) {
      nameInputRef.current.focus();
      nameInputRef.current.select();
    }
  }, [editingName]);

  useEffect(() => {
    if (editingDescription && descriptionRef.current) {
      descriptionRef.current.focus();
    }
  }, [editingDescription]);

  const handleNameSubmit = () => {
    if (nameValue.trim() && nameValue !== task.name) {
      onUpdate({ name: nameValue.trim() });
    } else {
      setNameValue(task.name);
    }
    setEditingName(false);
  };

  const handleDescriptionSubmit = () => {
    if (descriptionValue !== task.description) {
      onUpdate({ description: descriptionValue || null });
    }
    setEditingDescription(false);
  };

  const handleStatusChange = (value: string) => {
    if (value === "none") {
      onUpdate({ status: null });
    } else {
      onUpdate({ status: value as Task["status"] });
    }
  };

  const handlePriorityChange = (value: string) => {
    if (value === "none") {
      onUpdate({ priority: null });
    } else {
      onUpdate({ priority: value as Task["priority"] });
    }
  };

  const handleAssigneeChange = (value: string) => {
    if (value === "none") {
      onUpdate({ assignedMemberId: null });
    } else {
      onUpdate({ assignedMemberId: value });
    }
  };

  const handleStartDateChange = (date: Date | undefined) => {
    onUpdate({ startDate: date ? format(date, "yyyy-MM-dd") : null });
  };

  const handleDueDateChange = (date: Date | undefined) => {
    onUpdate({ dueDate: date ? format(date, "yyyy-MM-dd") : null });
  };

  const getAssigneeName = () => {
    if (!task.assignedMemberId) return null;
    return projectMembers.find((m) => m.id === task.assignedMemberId)?.name || "Unknown";
  };

  return (
    <div className="w-80 border-l bg-background flex flex-col fixed right-0 top-[57px] bottom-0 z-40 shadow-lg" data-testid="task-detail-panel">
      <div className="flex items-center justify-between gap-2 px-4 py-3 border-b">
        <h3 className="font-semibold text-sm">Task Details</h3>
        <Button
          variant="ghost"
          size="icon"
          className="h-6 w-6"
          onClick={onClose}
          data-testid="button-close-task-panel"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {editingName ? (
            <Input
              ref={nameInputRef}
              value={nameValue}
              onChange={(e) => setNameValue(e.target.value)}
              onBlur={handleNameSubmit}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleNameSubmit();
                if (e.key === "Escape") {
                  setNameValue(task.name);
                  setEditingName(false);
                }
              }}
              className="text-lg font-semibold"
              data-testid="input-panel-task-name"
            />
          ) : (
            <h2
              className="text-lg font-semibold cursor-pointer hover:bg-muted/50 px-2 py-1 -mx-2 rounded"
              onClick={() => setEditingName(true)}
              data-testid="text-panel-task-name"
            >
              {task.name}
            </h2>
          )}

          <div className="space-y-3">
            <div className="flex items-center justify-between gap-4">
              <span className="text-sm text-muted-foreground shrink-0">Status</span>
              <Select value={task.status || "none"} onValueChange={handleStatusChange}>
                <SelectTrigger 
                  className="h-8 text-sm w-[140px]"
                  data-testid="select-panel-status"
                >
                  {task.status ? (
                    <Badge
                      variant="secondary"
                      className={`${statusColors[task.status]} no-default-active-elevate pointer-events-none text-xs`}
                    >
                      {statusLabels[task.status]}
                    </Badge>
                  ) : (
                    <span className="text-muted-foreground/50">None</span>
                  )}
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="todo">To Do</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="complete">Complete</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between gap-4">
              <span className="text-sm text-muted-foreground shrink-0">Priority</span>
              <Select value={task.priority || "none"} onValueChange={handlePriorityChange}>
                <SelectTrigger 
                  className="h-8 text-sm w-[140px]"
                  data-testid="select-panel-priority"
                >
                  {task.priority ? (
                    <Badge
                      variant="secondary"
                      className={`${priorityColors[task.priority]} no-default-active-elevate pointer-events-none text-xs`}
                    >
                      {priorityLabels[task.priority]}
                    </Badge>
                  ) : (
                    <span className="text-muted-foreground/50">None</span>
                  )}
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center justify-between gap-4">
              <span className="text-sm text-muted-foreground shrink-0">Start Date</span>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "h-8 w-[140px] justify-start text-left font-normal text-sm",
                      !task.startDate && "text-muted-foreground/50"
                    )}
                    data-testid="button-panel-start-date"
                  >
                    <CalendarIcon className="mr-2 h-3 w-3" />
                    {task.startDate ? formatDate(task.startDate) : "None"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <Calendar
                    mode="single"
                    selected={task.startDate ? parseISO(task.startDate) : undefined}
                    onSelect={handleStartDateChange}
                    initialFocus
                  />
                  {task.startDate && (
                    <div className="p-2 border-t">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full"
                        onClick={() => handleStartDateChange(undefined)}
                      >
                        Clear date
                      </Button>
                    </div>
                  )}
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex items-center justify-between gap-4">
              <span className="text-sm text-muted-foreground shrink-0">Due Date</span>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "h-8 w-[140px] justify-start text-left font-normal text-sm",
                      !task.dueDate && "text-muted-foreground/50"
                    )}
                    data-testid="button-panel-due-date"
                  >
                    <CalendarIcon className="mr-2 h-3 w-3" />
                    {task.dueDate ? formatDate(task.dueDate) : "None"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="end">
                  <Calendar
                    mode="single"
                    selected={task.dueDate ? parseISO(task.dueDate) : undefined}
                    onSelect={handleDueDateChange}
                    initialFocus
                  />
                  {task.dueDate && (
                    <div className="p-2 border-t">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="w-full"
                        onClick={() => handleDueDateChange(undefined)}
                      >
                        Clear date
                      </Button>
                    </div>
                  )}
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex items-center justify-between gap-4">
              <span className="text-sm text-muted-foreground shrink-0">Assignee</span>
              <Select value={task.assignedMemberId || "none"} onValueChange={handleAssigneeChange}>
                <SelectTrigger 
                  className="h-8 text-sm w-[140px]"
                  data-testid="select-panel-assignee"
                >
                  {task.assignedMemberId && getAssigneeName() ? (
                    <span className="truncate">{getAssigneeName()}</span>
                  ) : (
                    <span className="text-muted-foreground/50">Unassigned</span>
                  )}
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Unassigned</SelectItem>
                  {projectMembers.map((member) => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="pt-2">
            <span className="text-sm text-muted-foreground block mb-2">Description</span>
            {editingDescription ? (
              <Textarea
                ref={descriptionRef}
                value={descriptionValue}
                onChange={(e) => setDescriptionValue(e.target.value)}
                onBlur={handleDescriptionSubmit}
                onKeyDown={(e) => {
                  if (e.key === "Escape") {
                    setDescriptionValue(task.description || "");
                    setEditingDescription(false);
                  }
                }}
                placeholder="Add a description..."
                className="min-h-[100px] text-sm resize-none"
                data-testid="textarea-panel-description"
              />
            ) : (
              <div
                className="text-sm cursor-pointer hover:bg-muted/50 px-2 py-1.5 -mx-2 rounded min-h-[60px]"
                onClick={() => setEditingDescription(true)}
                data-testid="text-panel-description"
              >
                {task.description || (
                  <span className="text-muted-foreground/50">Click to add description...</span>
                )}
              </div>
            )}
          </div>
        </div>
      </ScrollArea>
    </div>
  );
}
