import { useState } from "react";
import { HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

export function UserGuide() {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          data-testid="button-user-guide"
        >
          <HelpCircle className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh]">
        <DialogHeader>
          <DialogTitle>TaskFlow User Guide</DialogTitle>
        </DialogHeader>
        <ScrollArea className="h-[70vh] pr-4">
          <div className="space-y-6 text-sm">
            <section>
              <h3 className="text-lg font-semibold mb-2">Getting Started</h3>
              <p className="text-muted-foreground mb-2">
                TaskFlow is a project management application that helps you organize your work into projects, sections, and tasks. Use the sidebar to navigate between projects and the main area to manage your tasks.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Projects</h3>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Create a project:</strong> Click the "New Project" button in the sidebar or on the home page.</li>
                <li><strong>Select a project:</strong> Click on any project name in the sidebar to view its details.</li>
                <li><strong>Rename a project:</strong> Click directly on the project name in the header to edit it inline.</li>
                <li><strong>Delete a project:</strong> Click the trash icon in the project header.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Sections</h3>
              <p className="text-muted-foreground mb-2">
                Sections help you organize tasks within a project (e.g., "To Do", "In Progress", "Done").
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Add a section:</strong> Click "Add Section" button or use the "+ Add section" row at the bottom of the task grid.</li>
                <li><strong>Rename a section:</strong> Click directly on the section name in the task grid to edit it inline.</li>
                <li><strong>Reorder sections:</strong> Drag sections by their handle (grip icon) to reorder them.</li>
                <li><strong>Delete a section:</strong> Click the trash icon next to the section name.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Tasks</h3>
              <p className="text-muted-foreground mb-2">
                Tasks are the individual work items within your project.
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Add a task:</strong> Click "Add Task" button or use the "+ Add task" row within any section.</li>
                <li><strong>Edit task properties:</strong> Click on any field (name, status, priority, dates) to edit it inline.</li>
                <li><strong>Reorder tasks:</strong> Drag tasks by their handle to reorder within a section.</li>
                <li><strong>Move tasks between sections:</strong> Drag a task and drop it into a different section.</li>
                <li><strong>Delete a task:</strong> Click the trash icon on the task row.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Task Properties</h3>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Name:</strong> The task title (required).</li>
                <li><strong>Status:</strong> To Do, In Progress, or Complete.</li>
                <li><strong>Priority:</strong> Low, Medium, High, or Critical.</li>
                <li><strong>Start Date:</strong> When work on the task begins.</li>
                <li><strong>Due Date:</strong> The deadline for the task.</li>
                <li><strong>Assignee:</strong> The team member responsible for the task.</li>
                <li><strong>Description:</strong> Additional details about the task (edit via the expand button).</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Team Management</h3>
              <p className="text-muted-foreground mb-2">
                Manage team members who can be assigned to tasks across your projects.
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Global team members:</strong> Click "Team Members" in the sidebar to manage all team members.</li>
                <li><strong>Add a team member:</strong> Enter their name and email, then click Add.</li>
                <li><strong>Remove a team member:</strong> Click the X button next to their name.</li>
                <li><strong>Project team:</strong> Go to the Team tab in any project to manage project-specific members.</li>
                <li><strong>Add member to project:</strong> Select from the dropdown and click Add.</li>
                <li><strong>Remove from project:</strong> Click the X button next to the member in the project Team tab.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Task Assignment</h3>
              <p className="text-muted-foreground mb-2">
                Assign tasks to team members who are part of the project.
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Assign a task:</strong> Click the Assignee field in the task row and select a team member.</li>
                <li><strong>Unassign a task:</strong> Select "Unassigned" from the assignee dropdown.</li>
                <li><strong>Note:</strong> Only team members added to the project can be assigned tasks in that project.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Status Reports</h3>
              <p className="text-muted-foreground mb-2">
                Track and communicate project progress with status reports.
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>View reports:</strong> Click the "Status" tab in any project.</li>
                <li><strong>Create a report:</strong> Click "Create Status Report" and fill in the details.</li>
                <li><strong>Report status options:</strong> On Track, At Risk, Off Track, On Hold, or Complete.</li>
                <li><strong>Edit a report:</strong> Click on any existing report to modify it.</li>
                <li><strong>Delete a report:</strong> Click the trash icon on the report card.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Project Tabs</h3>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Tasks:</strong> View and manage all tasks organized by sections.</li>
                <li><strong>Status:</strong> View and create status reports for the project.</li>
                <li><strong>Team:</strong> Manage team members assigned to this project.</li>
                <li><strong>Activity:</strong> View a timeline of all changes made to the project, including task updates, creations, and deletions.</li>
                <li><strong>About:</strong> View and edit the project description.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Task Details</h3>
              <p className="text-muted-foreground mb-2">
                View and edit task details in a dedicated panel or full page.
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Open details panel:</strong> Click the expand icon on any task row to open a side panel with all task properties.</li>
                <li><strong>Edit in panel:</strong> Click on any field in the details panel to edit it inline.</li>
                <li><strong>Close panel:</strong> Click the X button in the panel header to close it.</li>
                <li><strong>Full page view:</strong> Navigate to a task's dedicated page for a larger editing experience.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Activity Log</h3>
              <p className="text-muted-foreground mb-2">
                Track all changes made to your project over time.
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>View activity:</strong> Click the Activity tab in any project to see the timeline.</li>
                <li><strong>Activity types:</strong> See when tasks are created, updated, or deleted.</li>
                <li><strong>Change details:</strong> View what specific fields were changed and their old/new values.</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Drag and Drop</h3>
              <p className="text-muted-foreground mb-2">
                Use the grip handle on the left side of sections and tasks to drag and reorder them. You can:
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li>Reorder sections within a project</li>
                <li>Reorder tasks within a section</li>
                <li>Move tasks from one section to another</li>
              </ul>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Dark Mode</h3>
              <p className="text-muted-foreground">
                Toggle between light and dark mode using the sun/moon icon in the header. Your preference is saved automatically.
              </p>
            </section>

            <section>
              <h3 className="text-lg font-semibold mb-2">Keyboard Shortcuts</h3>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li><strong>Enter:</strong> Save changes when editing inline.</li>
                <li><strong>Escape:</strong> Cancel editing and discard changes.</li>
                <li><strong>Tab:</strong> Move to the next field when creating tasks.</li>
              </ul>
            </section>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
