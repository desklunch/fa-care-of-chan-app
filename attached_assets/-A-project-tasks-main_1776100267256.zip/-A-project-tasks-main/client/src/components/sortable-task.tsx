import { useSortable } from "@dnd-kit/sortable";
import type { Task } from "@shared/schema";

interface SortableTaskProps {
  task: Task;
  children: (dragHandleProps: React.HTMLAttributes<HTMLElement>) => React.ReactNode;
  showDropIndicator?: "before" | "after" | null;
}

export function SortableTask({ task, children, showDropIndicator }: SortableTaskProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    isDragging,
  } = useSortable({ 
    id: task.id,
    animateLayoutChanges: () => false,
  });

  return (
    <>
      {showDropIndicator === "before" && (
        <tr className="h-0">
          <td colSpan={8} className="p-0 h-[2px] bg-primary" />
        </tr>
      )}
      <tr 
        ref={setNodeRef} 
        style={{ opacity: isDragging ? 0.4 : 1 }}
        className={`border-b border-border ${isDragging ? "bg-muted/30" : ""}`}
        data-testid={`task-row-${task.id}`}
      >
        {children({ ...listeners, ...attributes })}
      </tr>
      {showDropIndicator === "after" && (
        <tr className="h-0">
          <td colSpan={8} className="p-0 h-[2px] bg-primary" />
        </tr>
      )}
    </>
  );
}
