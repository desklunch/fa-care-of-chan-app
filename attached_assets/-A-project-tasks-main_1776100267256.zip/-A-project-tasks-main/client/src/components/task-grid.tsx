import { useState, useCallback, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import {
  DndContext,
  DragEndEvent,
  DragOverEvent,
  DragStartEvent,
  DragOverlay,
  pointerWithin,
  rectIntersection,
  PointerSensor,
  useSensor,
  useSensors,
  CollisionDetection,
} from "@dnd-kit/core";
import {
  SortableContext,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { GripVertical, ChevronDown, ChevronRight, Plus, Trash2, Edit2, MoreHorizontal, Circle, Clock, CheckCircle2, AlertTriangle, AlertCircle, Minus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SortableSection } from "@/components/sortable-section";
import { SortableTask } from "@/components/sortable-task";
import { TaskRow } from "@/components/task-row";
import type { Section, Task, SectionWithTasks, TeamMember } from "@shared/schema";

interface TaskGridProps {
  sections: SectionWithTasks[];
  projectMembers: TeamMember[];
  onReorderSections: (sectionIds: string[]) => void;
  onReorderTasks: (sectionId: string, taskIds: string[]) => void;
  onMoveTask: (taskId: string, fromSectionId: string, toSectionId: string, newOrder: number) => void;
  onUpdateTask: (taskId: string, updates: Partial<Task>) => void;
  onDeleteTask: (taskId: string) => void;
  onEditSection: (section: Section) => void;
  onUpdateSection: (sectionId: string, updates: { name: string }) => void;
  onDeleteSection: (sectionId: string) => void;
  onCreateTask: (sectionId: string, name: string) => void;
  onCreateSection: (name: string) => void;
  onOpenTaskDetail?: (task: Task) => void;
}

function InlineNewTask({ 
  onSubmit, 
  onCancel 
}: { 
  onSubmit: (name: string) => void; 
  onCancel: () => void;
}) {
  const [name, setName] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && name.trim()) {
      onSubmit(name.trim());
    } else if (e.key === "Escape") {
      onCancel();
    }
  };

  return (
    <tr className="border-b border-border">
      <td className="hidden md:table-cell px-2 py-3 border-r border-border">
        <div className="w-6 h-6" />
      </td>
      <td className="px-4 py-3 md:border-r border-border">
        <Input
          ref={inputRef}
          value={name}
          onChange={(e) => setName(e.target.value)}
          onBlur={onCancel}
          onKeyDown={handleKeyDown}
          placeholder="Task name"
          className="h-8 w-full text-[15px]"
          data-testid="input-inline-new-task"
        />
      </td>
      <td className="hidden md:table-cell px-4 py-3 border-r border-border" />
      <td className="hidden md:table-cell px-4 py-3 border-r border-border" />
      <td className="hidden md:table-cell px-4 py-3 border-r border-border" />
      <td className="hidden md:table-cell px-4 py-3 border-r border-border" />
      <td className="hidden md:table-cell px-4 py-3 border-r border-border" />
      <td className="hidden md:table-cell px-4 py-3 border-r border-border" />
      <td className="hidden md:table-cell px-4 py-3" />
    </tr>
  );
}

function InlineNewSection({ 
  onSubmit, 
  onCancel 
}: { 
  onSubmit: (name: string) => void; 
  onCancel: () => void;
}) {
  const [name, setName] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && name.trim()) {
      onSubmit(name.trim());
    } else if (e.key === "Escape") {
      onCancel();
    }
  };

  return (
    <tr className="bg-muted/50 border-y-2 border-border">
      <td className="px-2 py-2">
        <div className="w-6 h-6" />
      </td>
      <td colSpan={9} className="px-4 py-2">
        <Input
          ref={inputRef}
          value={name}
          onChange={(e) => setName(e.target.value)}
          onBlur={onCancel}
          onKeyDown={handleKeyDown}
          placeholder="Section name"
          className="h-8 w-full text-sm font-semibold uppercase tracking-wider"
          data-testid="input-inline-new-section"
        />
      </td>
    </tr>
  );
}

function getInitials(name: string): string {
  return name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
}

function StatusIcon({ status }: { status: string | null }) {
  if (!status) return null;
  switch (status) {
    case "todo": return <Circle className="h-4 w-4 text-muted-foreground" />;
    case "in_progress": return <Clock className="h-4 w-4 text-blue-500" />;
    case "complete": return <CheckCircle2 className="h-4 w-4 text-green-500" />;
    default: return null;
  }
}

function PriorityIcon({ priority }: { priority: string | null }) {
  if (!priority) return null;
  switch (priority) {
    case "low": return <Minus className="h-4 w-4 text-slate-400" />;
    case "medium": return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
    case "high": return <AlertTriangle className="h-4 w-4 text-orange-500" />;
    case "critical": return <AlertCircle className="h-4 w-4 text-red-500" />;
    default: return null;
  }
}

interface DropTarget {
  type: "task" | "section";
  targetId: string;
  position: "before" | "after";
  targetSectionId?: string;
}

export function TaskGrid({
  sections,
  projectMembers,
  onReorderSections,
  onReorderTasks,
  onMoveTask,
  onUpdateTask,
  onDeleteTask,
  onEditSection,
  onUpdateSection,
  onDeleteSection,
  onCreateTask,
  onCreateSection,
  onOpenTaskDetail,
}: TaskGridProps) {
  const [collapsedSections, setCollapsedSections] = useState<Set<string>>(new Set());
  const [activeId, setActiveId] = useState<string | null>(null);
  const [activeType, setActiveType] = useState<"section" | "task" | null>(null);
  const [dropTarget, setDropTarget] = useState<DropTarget | null>(null);
  const [initialPointerY, setInitialPointerY] = useState<number>(0);
  const [pendingNewTaskSectionId, setPendingNewTaskSectionId] = useState<string | null>(null);
  const [pendingNewSection, setPendingNewSection] = useState<boolean>(false);
  const [taskCreationKey, setTaskCreationKey] = useState(0);
  const [editingSectionId, setEditingSectionId] = useState<string | null>(null);
  const [editingSectionName, setEditingSectionName] = useState("");
  const sectionInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingSectionId && sectionInputRef.current) {
      sectionInputRef.current.focus();
      sectionInputRef.current.select();
    }
  }, [editingSectionId]);

  const handleSectionNameClick = (section: Section) => {
    setEditingSectionId(section.id);
    setEditingSectionName(section.name);
  };

  const handleSectionNameSave = (sectionId: string) => {
    if (editingSectionName.trim() && editingSectionName.trim() !== sections.find(s => s.id === sectionId)?.name) {
      onUpdateSection(sectionId, { name: editingSectionName.trim() });
    }
    setEditingSectionId(null);
    setEditingSectionName("");
  };

  const handleSectionNameKeyDown = (e: React.KeyboardEvent, sectionId: string) => {
    if (e.key === "Enter") {
      handleSectionNameSave(sectionId);
    } else if (e.key === "Escape") {
      setEditingSectionId(null);
      setEditingSectionName("");
    }
  };

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const customCollisionDetection: CollisionDetection = (args) => {
    const pointerCollisions = pointerWithin(args);
    if (pointerCollisions.length > 0) {
      const filtered = pointerCollisions.filter(
        (collision) => collision.id !== args.active.id
      );
      if (filtered.length > 0) {
        return filtered;
      }
    }
    const rectCollisions = rectIntersection(args);
    return rectCollisions.filter((collision) => collision.id !== args.active.id);
  };

  const toggleSection = (sectionId: string) => {
    setCollapsedSections((prev) => {
      const next = new Set(prev);
      if (next.has(sectionId)) {
        next.delete(sectionId);
      } else {
        next.add(sectionId);
      }
      return next;
    });
  };

  const findSectionByTaskId = useCallback((taskId: string): SectionWithTasks | undefined => {
    return sections.find((section) =>
      section.tasks.some((task) => task.id === taskId)
    );
  }, [sections]);

  const findTaskById = useCallback((taskId: string): Task | undefined => {
    for (const section of sections) {
      const task = section.tasks.find((t) => t.id === taskId);
      if (task) return task;
    }
    return undefined;
  }, [sections]);

  const handleDragStart = (event: DragStartEvent) => {
    const { active, activatorEvent } = event;
    const id = active.id as string;

    if (sections.some((s) => s.id === id)) {
      setActiveType("section");
    } else {
      setActiveType("task");
    }
    setActiveId(id);
    setDropTarget(null);
    
    if (activatorEvent instanceof MouseEvent) {
      setInitialPointerY(activatorEvent.clientY);
    }
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (!over || !activeId) {
      setDropTarget(null);
      return;
    }

    const overId = over.id as string;
    
    if (activeType === "section") {
      const overSection = sections.find((s) => s.id === overId);
      if (overSection && overId !== activeId) {
        const overIndex = sections.findIndex((s) => s.id === overId);
        const activeIndex = sections.findIndex((s) => s.id === activeId);
        setDropTarget({
          type: "section",
          targetId: overId,
          position: activeIndex < overIndex ? "after" : "before",
        });
      } else {
        setDropTarget(null);
      }
      return;
    }

    if (activeType === "task") {
      const isOverSection = sections.some((s) => s.id === overId);
      
      if (isOverSection) {
        const overSection = sections.find((s) => s.id === overId);
        if (overSection) {
          setDropTarget({
            type: "task",
            targetId: overId,
            position: "after",
            targetSectionId: overId,
          });
        }
      } else {
        const overSection = findSectionByTaskId(overId);
        if (overSection && overId !== activeId) {
          const overIndex = overSection.tasks.findIndex((t) => t.id === overId);
          const activeSection = findSectionByTaskId(activeId);
          const activeIndex = activeSection?.tasks.findIndex((t) => t.id === activeId) ?? -1;
          
          const isSameSection = activeSection?.id === overSection.id;
          let position: "before" | "after" = "before";
          
          if (isSameSection && activeIndex < overIndex) {
            position = "after";
          } else if (!isSameSection) {
            const overRect = over.rect;
            const delta = event.delta;
            const currentPointerY = initialPointerY + delta.y;
            const midpoint = overRect.top + overRect.height / 2;
            position = currentPointerY > midpoint ? "after" : "before";
          }
          
          setDropTarget({
            type: "task",
            targetId: overId,
            position,
            targetSectionId: overSection.id,
          });
        } else {
          setDropTarget(null);
        }
      }
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (!over || !dropTarget) {
      setActiveId(null);
      setActiveType(null);
      setDropTarget(null);
      return;
    }

    const draggedId = active.id as string;

    if (activeType === "section" && dropTarget.type === "section") {
      const oldIndex = sections.findIndex((s) => s.id === draggedId);
      let newIndex = sections.findIndex((s) => s.id === dropTarget.targetId);
      
      if (dropTarget.position === "after") {
        newIndex = newIndex + 1;
      }
      
      if (oldIndex < newIndex) {
        newIndex = newIndex - 1;
      }
      
      if (oldIndex !== newIndex && oldIndex !== -1 && newIndex >= 0) {
        const newOrder = [...sections];
        const [removed] = newOrder.splice(oldIndex, 1);
        newOrder.splice(newIndex, 0, removed);
        onReorderSections(newOrder.map((s) => s.id));
      }
    } else if (activeType === "task" && dropTarget.type === "task") {
      const activeSection = findSectionByTaskId(draggedId);
      const targetSectionId = dropTarget.targetSectionId!;
      const targetSection = sections.find((s) => s.id === targetSectionId);
      
      if (!activeSection || !targetSection) {
        setActiveId(null);
        setActiveType(null);
        setDropTarget(null);
        return;
      }

      const isOverSection = sections.some((s) => s.id === dropTarget.targetId);
      
      if (isOverSection) {
        if (activeSection.id !== targetSectionId) {
          onMoveTask(draggedId, activeSection.id, targetSectionId, targetSection.tasks.length);
        }
      } else {
        const overIndex = targetSection.tasks.findIndex((t) => t.id === dropTarget.targetId);
        let newOrder = overIndex;
        
        if (dropTarget.position === "after") {
          newOrder = overIndex + 1;
        }

        if (activeSection.id === targetSectionId) {
          const oldIndex = activeSection.tasks.findIndex((t) => t.id === draggedId);
          if (oldIndex < newOrder) {
            newOrder = newOrder - 1;
          }
          
          if (oldIndex !== newOrder) {
            const newTaskOrder = [...activeSection.tasks];
            const [removed] = newTaskOrder.splice(oldIndex, 1);
            newTaskOrder.splice(newOrder, 0, removed);
            onReorderTasks(activeSection.id, newTaskOrder.map((t) => t.id));
          }
        } else {
          onMoveTask(draggedId, activeSection.id, targetSectionId, newOrder);
        }
      }
    }

    setActiveId(null);
    setActiveType(null);
    setDropTarget(null);
  };

  const handleDragCancel = () => {
    setActiveId(null);
    setActiveType(null);
    setDropTarget(null);
  };

  const getTaskDropIndicator = (taskId: string, sectionId: string): "before" | "after" | null => {
    if (!dropTarget || dropTarget.type !== "task" || dropTarget.targetSectionId !== sectionId) {
      return null;
    }
    if (dropTarget.targetId === taskId) {
      return dropTarget.position;
    }
    return null;
  };

  const getSectionDropIndicator = (sectionId: string): "before" | "after" | null => {
    if (!dropTarget || dropTarget.type !== "section") {
      return null;
    }
    if (dropTarget.targetId === sectionId) {
      return dropTarget.position;
    }
    return null;
  };

  const shouldShowEmptySectionIndicator = (sectionId: string): boolean => {
    if (!dropTarget || dropTarget.type !== "task") return false;
    return dropTarget.targetId === sectionId && dropTarget.targetSectionId === sectionId;
  };

  const activeTask = activeId && activeType === "task" ? findTaskById(activeId) : null;
  const activeSection = activeId && activeType === "section" ? sections.find((s) => s.id === activeId) : null;

  if (sections.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="rounded-full bg-muted p-4 mb-4">
          <GripVertical className="h-8 w-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold mb-2">No sections yet</h3>
        <p className="text-sm text-muted-foreground max-w-sm">
          Create your first section to start organizing tasks in this project.
        </p>
      </div>
    );
  }

  return (
    <>
      {/* Mobile View */}
      <div className="md:hidden">
        {sections.map((section) => {
          const isCollapsed = collapsedSections.has(section.id);
          return (
            <div key={section.id} className="border-b border-border">
              <div className="flex items-center gap-2 p-3 bg-muted/50">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={() => toggleSection(section.id)}
                  data-testid={`mobile-toggle-section-${section.id}`}
                >
                  {isCollapsed ? (
                    <ChevronRight className="h-4 w-4" />
                  ) : (
                    <ChevronDown className="h-4 w-4" />
                  )}
                </Button>
                <span className="text-sm font-semibold uppercase tracking-wider flex-1">
                  {section.name}
                </span>
                <Badge variant="secondary">{section.tasks.length}</Badge>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      data-testid={`mobile-section-menu-${section.id}`}
                    >
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onEditSection(section)}>
                      <Edit2 className="mr-2 h-4 w-4" />
                      Edit Section
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      className="text-destructive"
                      onClick={() => onDeleteSection(section.id)}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete Section
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              {!isCollapsed &&
                section.tasks.map((task) => {
                  const assignee = projectMembers.find(
                    (m) => m.id === task.assignedMemberId
                  );
                  return (
                    <div
                      key={task.id}
                      className="flex items-center gap-2 px-4 py-3 border-t border-border hover-elevate cursor-pointer"
                      onClick={() => onOpenTaskDetail?.(task)}
                      data-testid={`mobile-task-${task.id}`}
                    >
                      <span className="flex-1 truncate text-sm" data-testid={`mobile-task-name-${task.id}`}>{task.name}</span>
                      {assignee && (
                        <div className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs flex items-center justify-center font-medium" data-testid={`mobile-task-assignee-${task.id}`}>
                          {getInitials(assignee.name)}
                        </div>
                      )}
                      <span data-testid={`mobile-task-status-${task.id}`}><StatusIcon status={task.status} /></span>
                      <span data-testid={`mobile-task-priority-${task.id}`}><PriorityIcon priority={task.priority} /></span>
                    </div>
                  );
                })}
              {!isCollapsed && section.tasks.length === 0 && (
                <div className="px-4 py-4 text-center text-sm text-muted-foreground border-t border-border">
                  No tasks
                </div>
              )}
            </div>
          );
        })}
        <div className="p-3">
          <Button
            variant="ghost"
            size="sm"
            className="text-muted-foreground"
            onClick={() => setPendingNewSection(true)}
            data-testid="mobile-button-add-section"
          >
            <Plus className="h-3 w-3 mr-1" />
            Add section
          </Button>
        </div>
      </div>

      {/* Desktop View */}
      <div className="hidden md:block">
        <DndContext
          sensors={sensors}
          collisionDetection={customCollisionDetection}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
          onDragCancel={handleDragCancel}
        >
          <div className="overflow-x-hidden md:overflow-x-visible">
        <table className="w-full md:min-w-[1050px] border-collapse table-fixed md:table-auto" data-testid="table-tasks">
          <thead className="sticky top-0 z-10 bg-background border-b">
            <tr>
              <th className="w-10 px-2 py-3 text-left hidden md:table-cell"></th>
              <th className="w-full md:w-auto px-4 py-3 text-left text-[13px] font-medium text-muted-foreground md:min-w-[280px]">
                <span className="hidden md:inline">Task Name</span>
              </th>
              <th className="hidden md:table-cell min-w-[120px] px-4 py-3 text-left text-[13px] font-medium text-muted-foreground">
                Status
              </th>
              <th className="hidden md:table-cell min-w-[120px] px-4 py-3 text-left text-[13px] font-medium text-muted-foreground">
                Start Date
              </th>
              <th className="hidden md:table-cell min-w-[120px] px-4 py-3 text-left text-[13px] font-medium text-muted-foreground">
                Due Date
              </th>
              <th className="hidden md:table-cell min-w-[100px] px-4 py-3 text-left text-[13px] font-medium text-muted-foreground">
                Priority
              </th>
              <th className="hidden md:table-cell min-w-[130px] px-4 py-3 text-left text-[13px] font-medium text-muted-foreground">
                Assignee
              </th>
              <th className="hidden md:table-cell min-w-[200px] px-4 py-3 text-left text-[13px] font-medium text-muted-foreground">
                Description
              </th>
              <th className="hidden md:table-cell w-20 px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            <SortableContext
              items={sections.map((s) => s.id)}
              strategy={verticalListSortingStrategy}
            >
              {sections.map((section) => {
                const isCollapsed = collapsedSections.has(section.id);
                const sectionIndicator = getSectionDropIndicator(section.id);
                return (
                  <SortableSection 
                    key={section.id} 
                    section={section}
                    showDropIndicator={sectionIndicator}
                  >
                    {(dragHandleProps: React.HTMLAttributes<HTMLElement>, setNodeRef: (element: HTMLElement | null) => void) => (
                      <>
                        <tr
                          ref={setNodeRef}
                          className="bg-muted/50 border-y-2 border-border"
                          style={dragHandleProps.style as React.CSSProperties}
                          data-testid={`section-header-${section.id}`}
                        >
                          <td className="hidden md:table-cell px-2 py-2">
                            <button
                              {...dragHandleProps}
                              className="flex items-center justify-center w-6 h-6 rounded cursor-grab active:cursor-grabbing hover-elevate"
                              data-testid={`drag-handle-section-${section.id}`}
                            >
                              <GripVertical className="h-4 w-4 text-muted-foreground" />
                            </button>
                          </td>
                          <td colSpan={8} className="px-4 py-2">
                            <div className="flex items-center justify-start gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6"
                                onClick={() => toggleSection(section.id)}
                                data-testid={`button-toggle-section-${section.id}`}
                              >
                                {isCollapsed ? (
                                  <ChevronRight className="h-4 w-4" />
                                ) : (
                                  <ChevronDown className="h-4 w-4" />
                                )}
                              </Button>
                              {editingSectionId === section.id ? (
                                <Input
                                  ref={sectionInputRef}
                                  value={editingSectionName}
                                  onChange={(e) => setEditingSectionName(e.target.value)}
                                  onBlur={() => handleSectionNameSave(section.id)}
                                  onKeyDown={(e) => handleSectionNameKeyDown(e, section.id)}
                                  className="h-7 w-48 text-sm font-semibold uppercase tracking-wider"
                                  data-testid={`input-section-name-${section.id}`}
                                />
                              ) : (
                                <span
                                  className="text-sm font-semibold uppercase tracking-wider cursor-pointer hover:text-primary"
                                  onClick={() => handleSectionNameClick(section)}
                                  data-testid={`text-section-name-${section.id}`}
                                >
                                  {section.name}
                                </span>
                              )}
                              <Badge variant="secondary" className="ml-2">
                                {section.tasks.length}
                              </Badge>
                              <div className="flex items-center gap-1 ml-auto md:ml-0">
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-6 w-6"
                                      data-testid={`button-section-menu-${section.id}`}
                                  >
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem
                                    onClick={() => onEditSection(section)}
                                    data-testid={`menu-edit-section-${section.id}`}
                                  >
                                    <Edit2 className="mr-2 h-4 w-4" />
                                    Edit Section
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => onDeleteSection(section.id)}
                                    data-testid={`menu-delete-section-${section.id}`}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Delete Section
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                              </div>
                            </div>
                          </td>
                        </tr>
                        {!isCollapsed && (
                          <SortableContext
                            items={section.tasks.map((t) => t.id)}
                            strategy={verticalListSortingStrategy}
                          >
                            {section.tasks.length === 0 ? (
                              <>
                                {shouldShowEmptySectionIndicator(section.id) && (
                                  <tr className="h-0">
                                    <td colSpan={9} className="p-0 relative">
                                      <div className="absolute left-0 right-0 top-0 h-[2px] bg-primary z-10" />
                                    </td>
                                  </tr>
                                )}
                                {pendingNewTaskSectionId === section.id && (
                                  <InlineNewTask
                                    key={`new-task-${section.id}-${taskCreationKey}`}
                                    onSubmit={(name) => {
                                      onCreateTask(section.id, name);
                                      setTaskCreationKey((k) => k + 1);
                                    }}
                                    onCancel={() => setPendingNewTaskSectionId(null)}
                                  />
                                )}
                                <tr>
                                  <td colSpan={9} className="px-4 py-6 text-center">
                                    {pendingNewTaskSectionId !== section.id && (
                                      <p className="text-sm text-muted-foreground mb-2">
                                        No tasks in this section
                                      </p>
                                    )}
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => setPendingNewTaskSectionId(section.id)}
                                      data-testid={`button-add-first-task-${section.id}`}
                                    >
                                      <Plus className="h-3 w-3 mr-1" />
                                      Add task
                                    </Button>
                                  </td>
                                </tr>
                              </>
                            ) : (
                              <>
                                {section.tasks.map((task) => (
                                  <SortableTask 
                                    key={task.id} 
                                    task={task}
                                    showDropIndicator={getTaskDropIndicator(task.id, section.id)}
                                  >
                                    {(dragHandleProps: React.HTMLAttributes<HTMLElement>) => (
                                      <TaskRow
                                        task={task}
                                        dragHandleProps={dragHandleProps}
                                        onUpdate={(updates) => onUpdateTask(task.id, updates)}
                                        onDelete={() => onDeleteTask(task.id)}
                                        onOpenDetail={onOpenTaskDetail ? () => onOpenTaskDetail(task) : undefined}
                                        projectMembers={projectMembers}
                                      />
                                    )}
                                  </SortableTask>
                                ))}
                                {pendingNewTaskSectionId === section.id && (
                                  <InlineNewTask
                                    key={`new-task-${section.id}-${taskCreationKey}`}
                                    onSubmit={(name) => {
                                      onCreateTask(section.id, name);
                                      setTaskCreationKey((k) => k + 1);
                                    }}
                                    onCancel={() => setPendingNewTaskSectionId(null)}
                                  />
                                )}
                                <tr>
                                  <td colSpan={9} className="px-4 py-1">
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="text-muted-foreground h-7 px-2"
                                      onClick={() => setPendingNewTaskSectionId(section.id)}
                                      data-testid={`button-add-task-bottom-${section.id}`}
                                    >
                                      <Plus className="h-3 w-3 mr-1" />
                                      Add task
                                    </Button>
                                  </td>
                                </tr>
                              </>
                            )}
                          </SortableContext>
                        )}
                      </>
                    )}
                  </SortableSection>
                );
              })}
            </SortableContext>
            {pendingNewSection && (
              <InlineNewSection
                onSubmit={(name) => {
                  onCreateSection(name);
                  setPendingNewSection(false);
                }}
                onCancel={() => setPendingNewSection(false)}
              />
            )}
            <tr>
              <td colSpan={9} className="px-4 py-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground h-7 px-2"
                  onClick={() => setPendingNewSection(true)}
                  data-testid="button-add-section-table-bottom"
                >
                  <Plus className="h-3 w-3 mr-1" />
                  Add section
                </Button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <DragOverlay dropAnimation={null}>
        {activeTask && (
          <div className="pointer-events-none">
            <table className="w-full bg-background/95 border border-primary/20 rounded-md shadow-lg">
              <tbody>
                <tr>
                  <TaskRow
                    task={activeTask}
                    dragHandleProps={{}}
                    onUpdate={() => {}}
                    onDelete={() => {}}
                    isOverlay
                    projectMembers={projectMembers}
                  />
                </tr>
              </tbody>
            </table>
          </div>
        )}
        {activeSection && (
          <div className="pointer-events-none bg-muted/95 border border-primary/20 rounded-md shadow-lg px-4 py-2">
            <div className="flex items-center gap-2">
              <GripVertical className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-semibold uppercase tracking-wider">
                {activeSection.name}
              </span>
              <Badge variant="secondary" className="ml-2">
                {activeSection.tasks.length}
              </Badge>
            </div>
          </div>
        )}
          </DragOverlay>
        </DndContext>
      </div>
    </>
  );
}
