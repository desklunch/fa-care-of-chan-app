import { ScrollArea } from "@/components/ui/scroll-area";

export default function GuidePage() {
  return (
    <div className="h-full p-8">
      <ScrollArea className="h-full">
        <div className="max-w-2xl space-y-6 text-sm">
          <h1 className="text-2xl font-semibold mb-4">TaskFlow User Guide</h1>

          <section>
            <h3 className="text-lg font-semibold mb-2">Getting Started</h3>
            <p className="text-muted-foreground mb-2">
              TaskFlow is a project management application that helps you organize your work into projects, sections, and tasks. Use the sidebar to navigate between projects and the main area to manage your tasks.
            </p>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Projects</h3>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong>Create a project:</strong> Click the "New Project" button in the sidebar or on the home page.</li>
              <li><strong>Select a project:</strong> Click on any project name in the sidebar to view its details.</li>
              <li><strong>Rename a project:</strong> Click directly on the project name in the header to edit it inline.</li>
              <li><strong>Delete a project:</strong> Click the trash icon in the project header.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Sections</h3>
            <p className="text-muted-foreground mb-2">
              Sections help you organize tasks within a project (e.g., "To Do", "In Progress", "Done").
            </p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong>Add a section:</strong> Click "Add Section" button or use the "+ Add section" row at the bottom of the task grid.</li>
              <li><strong>Rename a section:</strong> Click directly on the section name in the task grid to edit it inline.</li>
              <li><strong>Reorder sections:</strong> Drag sections by their handle (grip icon) to reorder them.</li>
              <li><strong>Delete a section:</strong> Click the trash icon next to the section name.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Tasks</h3>
            <p className="text-muted-foreground mb-2">
              Tasks are the individual work items within your project.
            </p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong>Add a task:</strong> Click "Add Task" button or use the "+ Add task" row within any section.</li>
              <li><strong>Edit task properties:</strong> Click on any field (name, status, priority, dates) to edit it inline.</li>
              <li><strong>Reorder tasks:</strong> Drag tasks by their handle to reorder within a section.</li>
              <li><strong>Move tasks between sections:</strong> Drag a task and drop it into a different section.</li>
              <li><strong>Delete a task:</strong> Click the trash icon on the task row.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Task Properties</h3>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong>Name:</strong> The task title (required).</li>
              <li><strong>Status:</strong> To Do, In Progress, or Complete.</li>
              <li><strong>Priority:</strong> Low, Medium, High, or Critical.</li>
              <li><strong>Start Date:</strong> When work on the task begins.</li>
              <li><strong>Due Date:</strong> The deadline for the task.</li>
              <li><strong>Description:</strong> Additional details about the task (edit via the expand button).</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Status Reports</h3>
            <p className="text-muted-foreground mb-2">
              Track and communicate project progress with status reports.
            </p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong>View reports:</strong> Click the "Status" tab in any project.</li>
              <li><strong>Create a report:</strong> Click "Create Status Report" and fill in the details.</li>
              <li><strong>Report status options:</strong> On Track, At Risk, Off Track, On Hold, or Complete.</li>
              <li><strong>Edit a report:</strong> Click on any existing report to modify it.</li>
              <li><strong>Delete a report:</strong> Click the trash icon on the report card.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Project Tabs</h3>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong>Tasks:</strong> View and manage all tasks organized by sections.</li>
              <li><strong>Status:</strong> View and create status reports for the project.</li>
              <li><strong>About:</strong> View and edit the project description.</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Drag and Drop</h3>
            <p className="text-muted-foreground mb-2">
              Use the grip handle on the left side of sections and tasks to drag and reorder them. You can:
            </p>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li>Reorder sections within a project</li>
              <li>Reorder tasks within a section</li>
              <li>Move tasks from one section to another</li>
            </ul>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Dark Mode</h3>
            <p className="text-muted-foreground">
              Toggle between light and dark mode using the sun/moon icon in the header. Your preference is saved automatically.
            </p>
          </section>

          <section>
            <h3 className="text-lg font-semibold mb-2">Keyboard Shortcuts</h3>
            <ul className="list-disc list-inside space-y-1 text-muted-foreground">
              <li><strong>Enter:</strong> Save changes when editing inline.</li>
              <li><strong>Escape:</strong> Cancel editing and discard changes.</li>
              <li><strong>Tab:</strong> Move to the next field when creating tasks.</li>
            </ul>
          </section>
        </div>
      </ScrollArea>
    </div>
  );
}
