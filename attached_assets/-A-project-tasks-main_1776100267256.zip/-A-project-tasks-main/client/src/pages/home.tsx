import { FolderKanban } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HomeProps {
  onCreateProject: () => void;
  hasProjects: boolean;
}

export default function Home({ onCreateProject, hasProjects }: HomeProps) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-8 py-16">
      <div className="max-w-md text-center">
        <div className="mx-auto w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-6">
          <FolderKanban className="h-8 w-8 text-primary" />
        </div>
        <h1 className="text-2xl font-semibold mb-3">
          {hasProjects ? "Select a Project" : "Welcome to TaskFlow"}
        </h1>
        <p className="text-muted-foreground mb-6">
          {hasProjects
            ? "Choose a project from the sidebar to view and manage its tasks."
            : "Get started by creating your first project. Organize your work with sections and tasks."}
        </p>
        {!hasProjects && (
          <Button onClick={onCreateProject} data-testid="button-create-project-home">
            Create Your First Project
          </Button>
        )}
      </div>
    </div>
  );
}
