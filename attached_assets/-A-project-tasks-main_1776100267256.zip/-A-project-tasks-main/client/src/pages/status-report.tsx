import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ArrowLeft, Save, Loader2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Project, StatusReport, StatusReportStatus } from "@shared/schema";

const statusOptions: StatusReportStatus[] = [
  "On Track",
  "At Risk",
  "Off Track",
  "On Hold",
  "Complete",
];

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  status: z.enum(["On Track", "At Risk", "Off Track", "On Hold", "Complete"], {
    required_error: "Status is required",
  }),
});

type FormData = z.infer<typeof formSchema>;

interface StatusReportPageProps {
  projectId: string;
  reportId?: string;
}

export default function StatusReportPage({ projectId, reportId }: StatusReportPageProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const isEditing = !!reportId && reportId !== "new";

  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
  });

  const { data: existingReport, isLoading: reportLoading } = useQuery<StatusReport>({
    queryKey: ["/api/status-reports", reportId],
    enabled: isEditing,
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      status: undefined,
    },
  });

  useEffect(() => {
    if (existingReport) {
      form.reset({
        title: existingReport.title,
        status: existingReport.status,
      });
    }
  }, [existingReport, form]);

  const createMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest("POST", `/api/projects/${projectId}/status-reports`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "status-reports"] });
      toast({ title: "Status report created" });
      setLocation(`/projects/${projectId}`);
    },
    onError: () => {
      toast({ title: "Failed to create status report", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: FormData) => {
      return apiRequest("PATCH", `/api/status-reports/${reportId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "status-reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/status-reports", reportId] });
      toast({ title: "Status report updated" });
      setLocation(`/projects/${projectId}`);
    },
    onError: () => {
      toast({ title: "Failed to update status report", variant: "destructive" });
    },
  });

  const onSubmit = (data: FormData) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;
  const isLoading = projectLoading || (isEditing && reportLoading);

  if (isLoading) {
    return (
      <div className="p-8 max-w-2xl">
        <Skeleton className="h-8 w-48 mb-6" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <p className="text-muted-foreground">Project not found</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <header className="flex items-center gap-4 px-8 py-4 border-b flex-wrap">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation(`/projects/${projectId}`)}
          data-testid="button-back-to-project"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-xl font-semibold" data-testid="text-page-title">
            {isEditing ? "Edit Status Report" : "Create Status Report"}
          </h1>
          <p className="text-sm text-muted-foreground">{project.name}</p>
        </div>
      </header>

      <div className="flex-1 overflow-auto p-8">
        <Card className="max-w-xl">
          <CardHeader>
            <CardTitle>Report Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter report title..."
                          {...field}
                          data-testid="input-report-title"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-report-status">
                            <SelectValue placeholder="Select status..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {statusOptions.map((status) => (
                            <SelectItem
                              key={status}
                              value={status}
                              data-testid={`option-status-${status.toLowerCase().replace(/\s+/g, "-")}`}
                            >
                              {status}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex items-center gap-2 pt-4 flex-wrap">
                  <Button
                    type="submit"
                    disabled={isPending}
                    data-testid="button-save-report"
                  >
                    {isPending ? (
                      <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4 mr-1" />
                    )}
                    {isEditing ? "Update Report" : "Create Report"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setLocation(`/projects/${projectId}`)}
                    data-testid="button-cancel-report"
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
