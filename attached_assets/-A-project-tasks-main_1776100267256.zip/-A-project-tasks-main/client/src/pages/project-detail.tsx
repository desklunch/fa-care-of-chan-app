import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Plus, LayoutGrid, Trash2, ListTodo, Info, FileText, Pencil, Users, UserPlus, X, Activity, Circle } from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { TaskGrid } from "@/components/task-grid";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { SectionDialog } from "@/components/section-dialog";
import { TaskDialog } from "@/components/task-dialog";
import { TaskDetailPanel } from "@/components/task-detail-panel";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Project, Section, Task, SectionWithTasks, StatusReport, StatusReportStatus, TeamMember, ActivityLogWithPerformer } from "@shared/schema";

interface ProjectDetailProps {
  projectId: string;
  onDeleteProject: () => void;
}

const statusColors: Record<StatusReportStatus, string> = {
  "On Track": "bg-green-500/15 text-green-700 dark:text-green-400",
  "At Risk": "bg-yellow-500/15 text-yellow-700 dark:text-yellow-400",
  "Off Track": "bg-red-500/15 text-red-700 dark:text-red-400",
  "On Hold": "bg-gray-500/15 text-gray-700 dark:text-gray-400",
  "Complete": "bg-blue-500/15 text-blue-700 dark:text-blue-400",
};

export default function ProjectDetail({ projectId, onDeleteProject }: ProjectDetailProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [sectionDialogOpen, setSectionDialogOpen] = useState(false);
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [editingSection, setEditingSection] = useState<Section | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [defaultSectionId, setDefaultSectionId] = useState<string>("");
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deletingSectionId, setDeletingSectionId] = useState<string | null>(null);
  const [deletingTaskId, setDeletingTaskId] = useState<string | null>(null);
  const [deletingReportId, setDeletingReportId] = useState<string | null>(null);
  const [editingProjectName, setEditingProjectName] = useState(false);
  const [projectNameValue, setProjectNameValue] = useState("");
  const projectNameInputRef = useRef<HTMLInputElement>(null);
  const [selectedTaskForPanel, setSelectedTaskForPanel] = useState<Task | null>(null);
  const [activeTab, setActiveTab] = useState("tasks");

  const { data: project, isLoading: projectLoading } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
  });

  const { data: sections = [], isLoading: sectionsLoading } = useQuery<SectionWithTasks[]>({
    queryKey: ["/api/projects", projectId, "sections"],
  });

  const { data: statusReports = [], isLoading: reportsLoading } = useQuery<StatusReport[]>({
    queryKey: ["/api/projects", projectId, "status-reports"],
  });

  const { data: projectMembers = [] } = useQuery<TeamMember[]>({
    queryKey: ["/api/projects", projectId, "members"],
  });

  const { data: allTeamMembers = [] } = useQuery<TeamMember[]>({
    queryKey: ["/api/team-members"],
  });

  const { data: activityLogs = [], isLoading: activityLoading } = useQuery<ActivityLogWithPerformer[]>({
    queryKey: ["/api/projects", projectId, "activity"],
  });

  const [selectedMemberToAdd, setSelectedMemberToAdd] = useState<string>("");

  const addProjectMemberMutation = useMutation({
    mutationFn: async (memberId: string) => {
      return apiRequest("POST", `/api/projects/${projectId}/members`, { memberId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "members"] });
      setSelectedMemberToAdd("");
      toast({ title: "Team member added to project" });
    },
    onError: () => {
      toast({ title: "Failed to add team member", variant: "destructive" });
    },
  });

  const removeProjectMemberMutation = useMutation({
    mutationFn: async (memberId: string) => {
      return apiRequest("DELETE", `/api/projects/${projectId}/members/${memberId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "members"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
      toast({ title: "Team member removed from project" });
    },
    onError: () => {
      toast({ title: "Failed to remove team member", variant: "destructive" });
    },
  });

  const availableTeamMembers = allTeamMembers.filter(
    (m) => !projectMembers.some((pm) => pm.id === m.id)
  );

  const deleteReportMutation = useMutation({
    mutationFn: async (reportId: string) => {
      return apiRequest("DELETE", `/api/status-reports/${reportId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "status-reports"] });
      setDeletingReportId(null);
      toast({ title: "Status report deleted" });
    },
    onError: () => {
      toast({ title: "Failed to delete status report", variant: "destructive" });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: async (data: { name: string }) => {
      return apiRequest("PATCH", `/api/projects/${projectId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setEditingProjectName(false);
    },
    onError: () => {
      toast({ title: "Failed to update project name", variant: "destructive" });
    },
  });

  useEffect(() => {
    if (editingProjectName && projectNameInputRef.current) {
      projectNameInputRef.current.focus();
      projectNameInputRef.current.select();
    }
  }, [editingProjectName]);

  const handleProjectNameClick = () => {
    if (project) {
      setProjectNameValue(project.name);
      setEditingProjectName(true);
    }
  };

  const handleProjectNameSave = () => {
    if (projectNameValue.trim() && projectNameValue.trim() !== project?.name) {
      updateProjectMutation.mutate({ name: projectNameValue.trim() });
    } else {
      setEditingProjectName(false);
    }
  };

  const handleProjectNameKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleProjectNameSave();
    } else if (e.key === "Escape") {
      setEditingProjectName(false);
    }
  };

  const createSectionMutation = useMutation({
    mutationFn: async (data: { name: string }) => {
      return apiRequest("POST", `/api/projects/${projectId}/sections`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
      setSectionDialogOpen(false);
      toast({ title: "Section created" });
    },
    onError: () => {
      toast({ title: "Failed to create section", variant: "destructive" });
    },
  });

  const updateSectionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: { name: string } }) => {
      return apiRequest("PATCH", `/api/sections/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
      setSectionDialogOpen(false);
      setEditingSection(null);
      toast({ title: "Section updated" });
    },
    onError: () => {
      toast({ title: "Failed to update section", variant: "destructive" });
    },
  });

  const deleteSectionMutation = useMutation({
    mutationFn: async (sectionId: string) => {
      return apiRequest("DELETE", `/api/sections/${sectionId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setDeletingSectionId(null);
      toast({ title: "Section deleted" });
    },
    onError: () => {
      toast({ title: "Failed to delete section", variant: "destructive" });
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: async (data: Partial<Task> & { sectionId: string }) => {
      return apiRequest("POST", `/api/projects/${projectId}/tasks`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setTaskDialogOpen(false);
      toast({ title: "Task created" });
    },
    onError: () => {
      toast({ title: "Failed to create task", variant: "destructive" });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Task> }) => {
      return apiRequest("PATCH", `/api/tasks/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
      setTaskDialogOpen(false);
      setEditingTask(null);
      toast({ title: "Task updated" });
    },
    onError: () => {
      toast({ title: "Failed to update task", variant: "destructive" });
    },
  });

  const inlineUpdateTaskMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Task> }) => {
      return apiRequest("PATCH", `/api/tasks/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
    },
    onError: () => {
      toast({ title: "Failed to update task", variant: "destructive" });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (taskId: string) => {
      return apiRequest("DELETE", `/api/tasks/${taskId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setDeletingTaskId(null);
      toast({ title: "Task deleted" });
    },
    onError: () => {
      toast({ title: "Failed to delete task", variant: "destructive" });
    },
  });

  const reorderSectionsMutation = useMutation({
    mutationFn: async (sectionIds: string[]) => {
      return apiRequest("POST", `/api/projects/${projectId}/sections/reorder`, { sectionIds });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
    },
    onError: () => {
      toast({ title: "Failed to reorder sections", variant: "destructive" });
    },
  });

  const reorderTasksMutation = useMutation({
    mutationFn: async ({ sectionId, taskIds }: { sectionId: string; taskIds: string[] }) => {
      return apiRequest("POST", `/api/sections/${sectionId}/tasks/reorder`, { taskIds });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
    },
    onError: () => {
      toast({ title: "Failed to reorder tasks", variant: "destructive" });
    },
  });

  const moveTaskMutation = useMutation({
    mutationFn: async ({
      taskId,
      fromSectionId,
      toSectionId,
      newOrder,
    }: {
      taskId: string;
      fromSectionId: string;
      toSectionId: string;
      newOrder: number;
    }) => {
      return apiRequest("POST", `/api/tasks/${taskId}/move`, {
        fromSectionId,
        toSectionId,
        newOrder,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
    },
    onError: () => {
      toast({ title: "Failed to move task", variant: "destructive" });
    },
  });

  const handleCreateSection = () => {
    setEditingSection(null);
    setSectionDialogOpen(true);
  };

  const handleEditSection = (section: Section) => {
    setEditingSection(section);
    setSectionDialogOpen(true);
  };

  const handleSectionSubmit = (data: { name: string }) => {
    if (editingSection) {
      updateSectionMutation.mutate({ id: editingSection.id, data });
    } else {
      createSectionMutation.mutate(data);
    }
  };

  const handleDeleteSection = (sectionId: string) => {
    setDeletingSectionId(sectionId);
  };

  const confirmDeleteSection = () => {
    if (deletingSectionId) {
      deleteSectionMutation.mutate(deletingSectionId);
    }
  };

  const handleAddTask = (sectionId: string) => {
    setEditingTask(null);
    setDefaultSectionId(sectionId);
    setTaskDialogOpen(true);
  };

  const handleInlineCreateTask = (sectionId: string, name: string) => {
    createTaskMutation.mutate({ sectionId, name });
  };

  const handleInlineCreateSection = (name: string) => {
    createSectionMutation.mutate({ name });
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setDefaultSectionId(task.sectionId);
    setTaskDialogOpen(true);
  };

  const handleUpdateTask = (taskId: string, updates: Partial<Task>) => {
    inlineUpdateTaskMutation.mutate({ id: taskId, data: updates });
  };

  const handleTaskSubmit = (data: Partial<Task> & { sectionId: string }) => {
    if (editingTask) {
      updateTaskMutation.mutate({ id: editingTask.id, data });
    } else {
      createTaskMutation.mutate(data);
    }
  };

  const handleDeleteTask = (taskId: string) => {
    setDeletingTaskId(taskId);
  };

  const confirmDeleteTask = () => {
    if (deletingTaskId) {
      deleteTaskMutation.mutate(deletingTaskId);
    }
  };

  const handleReorderSections = (sectionIds: string[]) => {
    reorderSectionsMutation.mutate(sectionIds);
  };

  const handleReorderTasks = (sectionId: string, taskIds: string[]) => {
    reorderTasksMutation.mutate({ sectionId, taskIds });
  };

  const handleMoveTask = (
    taskId: string,
    fromSectionId: string,
    toSectionId: string,
    newOrder: number
  ) => {
    moveTaskMutation.mutate({ taskId, fromSectionId, toSectionId, newOrder });
  };

  if (projectLoading || sectionsLoading) {
    return (
      <div className="p-8">
        <div className="flex items-center justify-between mb-6">
          <Skeleton className="h-8 w-48" />
          <div className="flex items-center gap-2">
            <Skeleton className="h-9 w-28" />
            <Skeleton className="h-9 w-28" />
          </div>
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-16 w-full" />
          ))}
        </div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <p className="text-muted-foreground">Project not found</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <header className="flex items-center justify-between gap-4 px-8 py-4 border-b flex-wrap">
        <div className="flex items-center gap-3">
          <LayoutGrid className="h-5 w-5 text-muted-foreground" />
          {editingProjectName ? (
            <Input
              ref={projectNameInputRef}
              value={projectNameValue}
              onChange={(e) => setProjectNameValue(e.target.value)}
              onBlur={handleProjectNameSave}
              onKeyDown={handleProjectNameKeyDown}
              className="h-8 w-64 text-xl font-semibold"
              data-testid="input-project-name"
            />
          ) : (
            <h1
              className="text-xl font-semibold cursor-pointer hover:text-primary"
              onClick={handleProjectNameClick}
              data-testid="text-project-name"
            >
              {project.name}
            </h1>
          )}
        </div>
        <div className="hidden md:flex items-center gap-2 flex-wrap">
          <Button
            variant="outline"
            size="sm"
            onClick={handleCreateSection}
            data-testid="button-add-section"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add Section
          </Button>
          <Button
            size="sm"
            onClick={() => {
              if (sections.length > 0) {
                handleAddTask(sections[0].id);
              } else {
                toast({
                  title: "Create a section first",
                  description: "You need at least one section to add tasks.",
                });
              }
            }}
            data-testid="button-add-task"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add Task
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-destructive"
            onClick={() => setDeleteConfirmOpen(true)}
            data-testid="button-delete-project"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </header>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden">
        <div className="px-4 pt-4">
          <div className="md:hidden">
            <Select value={activeTab} onValueChange={setActiveTab}>
              <SelectTrigger className="w-full" data-testid="select-tab-mobile">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tasks">
                  <span className="flex items-center gap-2">
                    <ListTodo className="h-4 w-4" />
                    Tasks
                  </span>
                </SelectItem>
                <SelectItem value="status">
                  <span className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Status
                  </span>
                </SelectItem>
                <SelectItem value="team">
                  <span className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Team
                  </span>
                </SelectItem>
                <SelectItem value="activity">
                  <span className="flex items-center gap-2">
                    <Activity className="h-4 w-4" />
                    Activity
                  </span>
                </SelectItem>
                <SelectItem value="about">
                  <span className="flex items-center gap-2">
                    <Info className="h-4 w-4" />
                    About
                  </span>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
          <TabsList className="hidden md:inline-flex">
            <TabsTrigger value="tasks" data-testid="tab-tasks">
              <ListTodo className="h-4 w-4 mr-2" />
              Tasks
            </TabsTrigger>
            <TabsTrigger value="status" data-testid="tab-status">
              <FileText className="h-4 w-4 mr-2" />
              Status
            </TabsTrigger>
            <TabsTrigger value="team" data-testid="tab-team">
              <Users className="h-4 w-4 mr-2" />
              Team
            </TabsTrigger>
            <TabsTrigger value="activity" data-testid="tab-activity">
              <Activity className="h-4 w-4 mr-2" />
              Activity
            </TabsTrigger>
            <TabsTrigger value="about" data-testid="tab-about">
              <Info className="h-4 w-4 mr-2" />
              About
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="tasks" className="flex-1 overflow-hidden mt-0">
          <div className="flex h-full">
            <div className="flex-1 overflow-auto p-4">
              <TaskGrid
                sections={sections}
                projectMembers={projectMembers}
                onReorderSections={handleReorderSections}
                onReorderTasks={handleReorderTasks}
                onMoveTask={handleMoveTask}
                onUpdateTask={handleUpdateTask}
                onDeleteTask={handleDeleteTask}
                onEditSection={handleEditSection}
                onUpdateSection={(sectionId, updates) => {
                  updateSectionMutation.mutate({ id: sectionId, data: updates });
                }}
                onDeleteSection={handleDeleteSection}
                onCreateTask={handleInlineCreateTask}
                onCreateSection={handleInlineCreateSection}
                onOpenTaskDetail={(task) => {
                  if (window.innerWidth < 768) {
                    setLocation(`/projects/${projectId}/tasks/${task.id}`);
                  } else {
                    setSelectedTaskForPanel(task);
                  }
                }}
              />
            </div>
            {selectedTaskForPanel && (() => {
              const freshTask = sections
                .flatMap(s => s.tasks)
                .find(t => t.id === selectedTaskForPanel.id);
              if (!freshTask) return null;
              return (
                <TaskDetailPanel
                  task={freshTask}
                  projectMembers={projectMembers}
                  onUpdate={(updates) => {
                    inlineUpdateTaskMutation.mutate({ id: freshTask.id, data: updates });
                  }}
                  onClose={() => setSelectedTaskForPanel(null)}
                />
              );
            })()}
          </div>
        </TabsContent>

        <TabsContent value="status" className="flex-1 overflow-auto p-4 mt-0">
          <div className="max-w-3xl space-y-4">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <h2 className="text-lg font-semibold">Status Reports</h2>
              <Button
                size="sm"
                onClick={() => setLocation(`/projects/${projectId}/status-reports/new`)}
                data-testid="button-create-status-report"
              >
                <Plus className="h-4 w-4 mr-1" />
                Create Report
              </Button>
            </div>

            {reportsLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : statusReports.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <FileText className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground mb-4">
                    No status reports yet
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => setLocation(`/projects/${projectId}/status-reports/new`)}
                    data-testid="button-create-first-status-report"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Create your first report
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {statusReports.map((report) => (
                  <Card key={report.id} data-testid={`card-status-report-${report.id}`}>
                    <CardContent className="py-4">
                      <div className="flex items-start justify-between gap-4 flex-wrap">
                        <div className="space-y-1">
                          <h3 className="font-medium" data-testid={`text-report-title-${report.id}`}>
                            {report.title}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(report.createdAt), "MMM d, yyyy 'at' h:mm a")}
                          </p>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge 
                            className={`${statusColors[report.status]} no-default-hover-elevate no-default-active-elevate`}
                            data-testid={`badge-report-status-${report.id}`}
                          >
                            {report.status}
                          </Badge>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setLocation(`/projects/${projectId}/status-reports/${report.id}`)}
                            data-testid={`button-edit-report-${report.id}`}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-destructive"
                            onClick={() => setDeletingReportId(report.id)}
                            data-testid={`button-delete-report-${report.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="team" className="flex-1 overflow-auto p-4 mt-0">
          <div className="max-w-2xl space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Project Team</CardTitle>
                <CardDescription>
                  Manage team members who can be assigned tasks in this project
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <Select
                    value={selectedMemberToAdd}
                    onValueChange={setSelectedMemberToAdd}
                  >
                    <SelectTrigger className="flex-1" data-testid="select-add-member">
                      <SelectValue placeholder="Select team member to add..." />
                    </SelectTrigger>
                    <SelectContent>
                      {availableTeamMembers.length === 0 ? (
                        <SelectItem value="none" disabled>
                          No team members available
                        </SelectItem>
                      ) : (
                        availableTeamMembers.map((member) => (
                          <SelectItem key={member.id} value={member.id}>
                            {member.name}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                  <Button
                    onClick={() => {
                      if (selectedMemberToAdd) {
                        addProjectMemberMutation.mutate(selectedMemberToAdd);
                      }
                    }}
                    disabled={!selectedMemberToAdd || addProjectMemberMutation.isPending}
                    data-testid="button-add-member-to-project"
                  >
                    <UserPlus className="h-4 w-4 mr-1" />
                    Add
                  </Button>
                </div>

                {projectMembers.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <Users className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No team members assigned to this project</p>
                    <p className="text-xs mt-1">Add team members above to start assigning tasks</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-muted-foreground">
                      {projectMembers.length} team member{projectMembers.length !== 1 ? "s" : ""}
                    </h4>
                    {projectMembers.map((member) => (
                      <div
                        key={member.id}
                        className="flex items-center justify-between p-3 rounded-md bg-muted/50"
                        data-testid={`project-member-${member.id}`}
                      >
                        <div>
                          <div className="font-medium">{member.name}</div>
                          {member.email && (
                            <div className="text-xs text-muted-foreground">{member.email}</div>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeProjectMemberMutation.mutate(member.id)}
                          disabled={removeProjectMemberMutation.isPending}
                          data-testid={`button-remove-member-${member.id}`}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="activity" className="flex-1 overflow-auto p-4 mt-0">
          <div className="max-w-3xl space-y-4">
            <h2 className="text-lg font-semibold">Activity Timeline</h2>
            
            {activityLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : activityLogs.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <Activity className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">
                    No activity recorded yet
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    Activity will appear here when tasks are created, updated, or deleted
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="relative">
                <div className="absolute left-3 top-0 bottom-0 w-px bg-border" />
                <div className="space-y-4">
                  {activityLogs.map((log) => (
                    <div
                      key={log.id}
                      className="relative pl-8"
                      data-testid={`activity-log-${log.id}`}
                    >
                      <div className="absolute left-0 top-1.5 w-6 h-6 rounded-full bg-background border-2 border-muted-foreground/30 flex items-center justify-center">
                        <Circle className="h-2 w-2 fill-muted-foreground text-muted-foreground" />
                      </div>
                      <Card>
                        <CardContent className="py-3 px-4">
                          <div className="flex items-start justify-between gap-2 flex-wrap">
                            <div className="space-y-1">
                              <p className="text-sm">
                                {log.action === "created" && (
                                  <span>
                                    <span className="font-medium capitalize">{log.entityType}</span> was created
                                  </span>
                                )}
                                {log.action === "updated" && (
                                  <span>
                                    <span className="font-medium capitalize">{log.entityType}</span> {log.field} changed
                                    {log.oldValue && log.newValue && (
                                      <span className="text-muted-foreground">
                                        {" "}from "{log.oldValue}" to "{log.newValue}"
                                      </span>
                                    )}
                                  </span>
                                )}
                                {log.action === "deleted" && (
                                  <span>
                                    <span className="font-medium capitalize">{log.entityType}</span> was deleted
                                  </span>
                                )}
                              </p>
                              {log.performerName && (
                                <p className="text-xs text-muted-foreground">
                                  by {log.performerName}
                                </p>
                              )}
                            </div>
                            <span className="text-xs text-muted-foreground whitespace-nowrap">
                              {format(new Date(log.timestamp), "MMM d, h:mm a")}
                            </span>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="about" className="flex-1 overflow-auto p-4 mt-0">
          <div className="max-w-2xl space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Project Description</CardTitle>
                <CardDescription>
                  Add details about the purpose and goals of this project
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Textarea
                  placeholder="Describe your project..."
                  className="min-h-[120px] resize-none"
                  value={project.description || ""}
                  readOnly
                  data-testid="textarea-project-description"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Project description editing coming soon
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Project Info</CardTitle>
                <CardDescription>
                  Additional project properties will be displayed here
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Sections</span>
                    <span>{sections.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Tasks</span>
                    <span>{sections.reduce((acc, s) => acc + s.tasks.length, 0)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <SectionDialog
        open={sectionDialogOpen}
        onOpenChange={setSectionDialogOpen}
        section={editingSection}
        onSubmit={handleSectionSubmit}
        isPending={createSectionMutation.isPending || updateSectionMutation.isPending}
      />

      <TaskDialog
        open={taskDialogOpen}
        onOpenChange={setTaskDialogOpen}
        task={editingTask}
        sections={sections}
        defaultSectionId={defaultSectionId}
        onSubmit={handleTaskSubmit}
        isPending={createTaskMutation.isPending || updateTaskMutation.isPending}
      />

      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent data-testid="dialog-delete-project">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Project</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this project? This will also delete all sections and tasks. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete-project">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={onDeleteProject}
              className="bg-destructive text-destructive-foreground"
              data-testid="button-confirm-delete-project"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog
        open={!!deletingSectionId}
        onOpenChange={(open) => !open && setDeletingSectionId(null)}
      >
        <AlertDialogContent data-testid="dialog-delete-section">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Section</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this section? All tasks in this section will also be deleted. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete-section">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteSection}
              className="bg-destructive text-destructive-foreground"
              data-testid="button-confirm-delete-section"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog
        open={!!deletingTaskId}
        onOpenChange={(open) => !open && setDeletingTaskId(null)}
      >
        <AlertDialogContent data-testid="dialog-delete-task">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Task</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this task? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete-task">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteTask}
              className="bg-destructive text-destructive-foreground"
              data-testid="button-confirm-delete-task"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog
        open={!!deletingReportId}
        onOpenChange={(open) => !open && setDeletingReportId(null)}
      >
        <AlertDialogContent data-testid="dialog-delete-status-report">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Status Report</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this status report? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete-report">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deletingReportId && deleteReportMutation.mutate(deletingReportId)}
              className="bg-destructive text-destructive-foreground"
              data-testid="button-confirm-delete-report"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
