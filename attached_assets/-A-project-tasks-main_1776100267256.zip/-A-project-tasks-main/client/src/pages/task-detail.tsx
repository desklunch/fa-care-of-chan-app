import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { ArrowLeft, CalendarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Task, Project, TeamMember } from "@shared/schema";
import { format, parseISO } from "date-fns";
import { cn } from "@/lib/utils";

interface TaskDetailPageProps {
  projectId: string;
  taskId: string;
}

const statusColors: Record<string, string> = {
  todo: "bg-muted text-muted-foreground",
  in_progress: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
  complete: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
};

const statusLabels: Record<string, string> = {
  todo: "To Do",
  in_progress: "In Progress",
  complete: "Complete",
};

const priorityColors: Record<string, string> = {
  low: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
  high: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
  critical: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
};

const priorityLabels: Record<string, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
};

function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return "";
  try {
    return format(parseISO(dateString), "MMM d, yyyy");
  } catch {
    return dateString;
  }
}

export default function TaskDetailPage({ projectId, taskId }: TaskDetailPageProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: project } = useQuery<Project>({
    queryKey: ["/api/projects", projectId],
  });

  const { data: task, isLoading } = useQuery<Task>({
    queryKey: ["/api/tasks", taskId],
    queryFn: async () => {
      const res = await fetch(`/api/tasks/${taskId}`);
      if (!res.ok) throw new Error("Task not found");
      return res.json();
    },
  });

  const { data: projectMembers = [] } = useQuery<TeamMember[]>({
    queryKey: ["/api/projects", projectId, "members"],
  });

  const [editingName, setEditingName] = useState(false);
  const [nameValue, setNameValue] = useState("");
  const [editingDescription, setEditingDescription] = useState(false);
  const [descriptionValue, setDescriptionValue] = useState("");
  const nameInputRef = useRef<HTMLInputElement>(null);
  const descriptionRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (task) {
      setNameValue(task.name);
      setDescriptionValue(task.description || "");
    }
  }, [task]);

  useEffect(() => {
    if (editingName && nameInputRef.current) {
      nameInputRef.current.focus();
      nameInputRef.current.select();
    }
  }, [editingName]);

  useEffect(() => {
    if (editingDescription && descriptionRef.current) {
      descriptionRef.current.focus();
    }
  }, [editingDescription]);

  const updateTaskMutation = useMutation({
    mutationFn: async (data: Partial<Task>) => {
      return apiRequest("PATCH", `/api/tasks/${taskId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks", taskId] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects", projectId, "sections"] });
    },
    onError: () => {
      toast({ title: "Failed to update task", variant: "destructive" });
    },
  });

  const handleUpdate = (updates: Partial<Task>) => {
    updateTaskMutation.mutate(updates);
  };

  const handleNameSubmit = () => {
    if (task && nameValue.trim() && nameValue !== task.name) {
      handleUpdate({ name: nameValue.trim() });
    } else if (task) {
      setNameValue(task.name);
    }
    setEditingName(false);
  };

  const handleDescriptionSubmit = () => {
    if (task && descriptionValue !== task.description) {
      handleUpdate({ description: descriptionValue || null });
    }
    setEditingDescription(false);
  };

  const handleStatusChange = (value: string) => {
    if (value === "none") {
      handleUpdate({ status: null });
    } else {
      handleUpdate({ status: value as Task["status"] });
    }
  };

  const handlePriorityChange = (value: string) => {
    if (value === "none") {
      handleUpdate({ priority: null });
    } else {
      handleUpdate({ priority: value as Task["priority"] });
    }
  };

  const handleAssigneeChange = (value: string) => {
    if (value === "none") {
      handleUpdate({ assignedMemberId: null });
    } else {
      handleUpdate({ assignedMemberId: value });
    }
  };

  const handleStartDateChange = (date: Date | undefined) => {
    handleUpdate({ startDate: date ? format(date, "yyyy-MM-dd") : null });
  };

  const handleDueDateChange = (date: Date | undefined) => {
    handleUpdate({ dueDate: date ? format(date, "yyyy-MM-dd") : null });
  };

  const getAssigneeName = () => {
    if (!task?.assignedMemberId) return null;
    return projectMembers.find((m) => m.id === task.assignedMemberId)?.name || "Unknown";
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!task) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6">
        <p className="text-muted-foreground mb-4">Task not found</p>
        <Button variant="outline" onClick={() => setLocation(`/projects/${projectId}`)}>
          Back to Project
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full overflow-auto">
      <header className="flex items-center gap-3 px-6 py-4 border-b">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation(`/projects/${projectId}`)}
          data-testid="button-back-to-project"
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="text-sm text-muted-foreground">
          {project?.name || "Project"} / Task Details
        </div>
      </header>

      <div className="flex-1 p-6 max-w-2xl mx-auto w-full space-y-6">
        {editingName ? (
          <Input
            ref={nameInputRef}
            value={nameValue}
            onChange={(e) => setNameValue(e.target.value)}
            onBlur={handleNameSubmit}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleNameSubmit();
              if (e.key === "Escape") {
                setNameValue(task.name);
                setEditingName(false);
              }
            }}
            className="text-xl font-semibold"
            data-testid="input-page-task-name"
          />
        ) : (
          <h1
            className="text-xl font-semibold cursor-pointer hover:bg-muted/50 px-3 py-2 -mx-3 rounded"
            onClick={() => setEditingName(true)}
            data-testid="text-page-task-name"
          >
            {task.name}
          </h1>
        )}

        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <span className="text-sm text-muted-foreground shrink-0">Status</span>
            <Select value={task.status || "none"} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-[180px]" data-testid="select-page-status">
                {task.status ? (
                  <Badge
                    variant="secondary"
                    className={`${statusColors[task.status]} no-default-active-elevate pointer-events-none`}
                  >
                    {statusLabels[task.status]}
                  </Badge>
                ) : (
                  <span className="text-muted-foreground/50">None</span>
                )}
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="todo">To Do</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="complete">Complete</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between gap-4">
            <span className="text-sm text-muted-foreground shrink-0">Priority</span>
            <Select value={task.priority || "none"} onValueChange={handlePriorityChange}>
              <SelectTrigger className="w-[180px]" data-testid="select-page-priority">
                {task.priority ? (
                  <Badge
                    variant="secondary"
                    className={`${priorityColors[task.priority]} no-default-active-elevate pointer-events-none`}
                  >
                    {priorityLabels[task.priority]}
                  </Badge>
                ) : (
                  <span className="text-muted-foreground/50">None</span>
                )}
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between gap-4">
            <span className="text-sm text-muted-foreground shrink-0">Start Date</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-[180px] justify-start text-left font-normal",
                    !task.startDate && "text-muted-foreground/50"
                  )}
                  data-testid="button-page-start-date"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {task.startDate ? formatDate(task.startDate) : "None"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="single"
                  selected={task.startDate ? parseISO(task.startDate) : undefined}
                  onSelect={handleStartDateChange}
                  initialFocus
                />
                {task.startDate && (
                  <div className="p-2 border-t">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full"
                      onClick={() => handleStartDateChange(undefined)}
                    >
                      Clear date
                    </Button>
                  </div>
                )}
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex items-center justify-between gap-4">
            <span className="text-sm text-muted-foreground shrink-0">Due Date</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-[180px] justify-start text-left font-normal",
                    !task.dueDate && "text-muted-foreground/50"
                  )}
                  data-testid="button-page-due-date"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {task.dueDate ? formatDate(task.dueDate) : "None"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="single"
                  selected={task.dueDate ? parseISO(task.dueDate) : undefined}
                  onSelect={handleDueDateChange}
                  initialFocus
                />
                {task.dueDate && (
                  <div className="p-2 border-t">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full"
                      onClick={() => handleDueDateChange(undefined)}
                    >
                      Clear date
                    </Button>
                  </div>
                )}
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex items-center justify-between gap-4">
            <span className="text-sm text-muted-foreground shrink-0">Assignee</span>
            <Select value={task.assignedMemberId || "none"} onValueChange={handleAssigneeChange}>
              <SelectTrigger className="w-[180px]" data-testid="select-page-assignee">
                {task.assignedMemberId && getAssigneeName() ? (
                  <span className="truncate">{getAssigneeName()}</span>
                ) : (
                  <span className="text-muted-foreground/50">Unassigned</span>
                )}
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Unassigned</SelectItem>
                {projectMembers.map((member) => (
                  <SelectItem key={member.id} value={member.id}>
                    {member.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="pt-2">
          <span className="text-sm text-muted-foreground block mb-2">Description</span>
          {editingDescription ? (
            <Textarea
              ref={descriptionRef}
              value={descriptionValue}
              onChange={(e) => setDescriptionValue(e.target.value)}
              onBlur={handleDescriptionSubmit}
              onKeyDown={(e) => {
                if (e.key === "Escape") {
                  setDescriptionValue(task.description || "");
                  setEditingDescription(false);
                }
              }}
              placeholder="Add a description..."
              className="min-h-[120px] resize-none"
              data-testid="textarea-page-description"
            />
          ) : (
            <div
              className="text-sm cursor-pointer hover:bg-muted/50 px-3 py-2 -mx-3 rounded min-h-[80px]"
              onClick={() => setEditingDescription(true)}
              data-testid="text-page-description"
            >
              {task.description || (
                <span className="text-muted-foreground/50">Click to add description...</span>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
