import { useState } from "react";
import { Switch, Route, useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { UserGuide } from "@/components/user-guide";
import { ProjectDialog } from "@/components/project-dialog";
import Home from "@/pages/home";
import TeamMembers from "@/pages/team-members";
import GuidePage from "@/pages/guide";
import ProjectDetail from "@/pages/project-detail";
import StatusReportPage from "@/pages/status-report";
import TaskDetailPage from "@/pages/task-detail";
import NotFound from "@/pages/not-found";
import type { Project } from "@shared/schema";

function AppContent() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [projectDialogOpen, setProjectDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  const { data: projects = [], isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
  });

  const { data: taskCounts = {} } = useQuery<Record<string, number>>({
    queryKey: ["/api/projects/task-counts"],
  });

  const createProjectMutation = useMutation({
    mutationFn: async (data: { name: string; description?: string }) => {
      const response = await apiRequest("POST", "/api/projects", data);
      return response.json();
    },
    onSuccess: (newProject: Project) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setProjectDialogOpen(false);
      setLocation(`/projects/${newProject.id}`);
      toast({ title: "Project created" });
    },
    onError: () => {
      toast({ title: "Failed to create project", variant: "destructive" });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: async ({
      id,
      data,
    }: {
      id: string;
      data: { name: string; description?: string };
    }) => {
      return apiRequest("PATCH", `/api/projects/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setProjectDialogOpen(false);
      setEditingProject(null);
      toast({ title: "Project updated" });
    },
    onError: () => {
      toast({ title: "Failed to update project", variant: "destructive" });
    },
  });

  const deleteProjectMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/projects/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects/task-counts"] });
      setLocation("/");
      toast({ title: "Project deleted" });
    },
    onError: () => {
      toast({ title: "Failed to delete project", variant: "destructive" });
    },
  });

  const handleCreateProject = () => {
    setEditingProject(null);
    setProjectDialogOpen(true);
  };

  const handleProjectSubmit = (data: { name: string; description?: string }) => {
    if (editingProject) {
      updateProjectMutation.mutate({ id: editingProject.id, data });
    } else {
      createProjectMutation.mutate(data);
    }
  };

  const style = {
    "--sidebar-width": "17.5rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar
          projects={projects}
          taskCounts={taskCounts}
          isLoading={projectsLoading}
          onCreateProject={handleCreateProject}
        />
        <div className="flex flex-col flex-1 min-w-0">
          <header className="flex items-center justify-between gap-2 p-2 border-b shrink-0">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex items-center gap-1">
              <UserGuide />
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-hidden">
            <Switch>
              <Route path="/">
                <Home
                  onCreateProject={handleCreateProject}
                  hasProjects={projects.length > 0}
                />
              </Route>
              <Route path="/guide" component={GuidePage} />
              <Route path="/team" component={TeamMembers} />
              <Route path="/projects/:projectId">
                {(params) => (
                  <ProjectDetail
                    projectId={params.projectId}
                    onDeleteProject={() =>
                      deleteProjectMutation.mutate(params.projectId)
                    }
                  />
                )}
              </Route>
              <Route path="/projects/:projectId/status-reports/:reportId">
                {(params) => (
                  <StatusReportPage
                    projectId={params.projectId}
                    reportId={params.reportId}
                  />
                )}
              </Route>
              <Route path="/projects/:projectId/tasks/:taskId">
                {(params) => (
                  <TaskDetailPage
                    projectId={params.projectId}
                    taskId={params.taskId}
                  />
                )}
              </Route>
              <Route component={NotFound} />
            </Switch>
          </main>
        </div>
      </div>

      <ProjectDialog
        open={projectDialogOpen}
        onOpenChange={setProjectDialogOpen}
        project={editingProject}
        onSubmit={handleProjectSubmit}
        isPending={
          createProjectMutation.isPending || updateProjectMutation.isPending
        }
      />
    </SidebarProvider>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
