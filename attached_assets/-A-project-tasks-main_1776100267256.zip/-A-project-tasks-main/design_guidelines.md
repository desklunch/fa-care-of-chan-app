# Project Management App Design Guidelines

## Design Approach

**Reference-Based Approach:** Drawing inspiration from modern productivity tools (Linear, Asana, Notion) with emphasis on clarity, efficiency, and data density. The design prioritizes rapid task scanning, clear hierarchy, and frictionless drag-and-drop interactions.

## Core Design Principles

1. **Information Density Balance:** Maximize visible tasks while maintaining readability
2. **Hierarchical Clarity:** Section groups must be immediately distinguishable from task rows
3. **Drag Affordance:** Visual cues for draggability without visual noise
4. **Focused Workspace:** Minimize chrome, maximize content area

## Typography System

**Font Stack:** Inter (primary) via Google Fonts CDN
- Page headers: 24px, semibold (600)
- Section headers: 14px, semibold (600), uppercase with 0.5px letter-spacing
- Table column headers: 13px, medium (500)
- Task names: 15px, regular (400)
- Task properties: 14px, regular (400)
- Metadata/helpers: 13px, regular (400)

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, and 8 as core rhythm
- Component padding: p-6 or p-8
- Table cell padding: px-4 py-3
- Section group margins: mb-6
- Form field spacing: gap-4
- Page margins: px-8 py-6

**Grid Structure:**
- Sidebar: Fixed 280px width
- Main content: flex-1 with max-w-7xl container
- Table columns: Auto-sized based on content with min-widths (Name: min-w-80, Status: min-w-32, Dates: min-w-40, Priority: min-w-32, Description: min-w-96)

## Component Library

### Navigation & Layout
**Sidebar:**
- Projects list with create button at top
- Each project item shows name and task count
- Active project highlighted
- Compact, scannable list design

**Top Bar:**
- Project name (left)
- Action buttons: Add Task, Add Section (right)
- Breadcrumb if needed

### Data Grid/Table
**Structure:**
- Full-width table with fixed header row
- Column headers: Task Name | Status | Start Date | Due Date | Priority | Description
- Sticky header on scroll
- Zebra striping on hover only for task rows

**Section Groups:**
- Section header row spans full table width
- Drag handle icon on left of section name
- Task count badge on right
- Clear visual separation (thicker border, slightly elevated)
- Collapsible with chevron icon

**Task Rows:**
- Drag handle icon in leftmost position (before task name)
- Each property in dedicated column
- Inline editing on click for text fields
- Dropdowns for status and priority
- Date pickers for date fields
- Empty cells show subtle placeholder text on hover

**Drag & Drop States:**
- Dragging: Semi-transparent with slight elevation shadow
- Drop zones: Subtle border or background treatment on valid targets
- Invalid drops: Cursor change, no visual zone

### Forms & Inputs
**Project Form:**
- Modal overlay (centered, max-w-md)
- Project name input (required)
- Optional description textarea
- Create/Cancel buttons (right-aligned)

**Task Quick Add:**
- Inline row at top of section or table
- Only name field visible initially
- Expand to show all properties on focus

**Task Edit:**
- Inline editing within table cells
- Click to activate
- Escape to cancel, Enter to save
- Dropdown overlays for select fields

### Interactive Elements
**Buttons:**
- Primary: Medium size, rounded corners
- Secondary: Outlined style
- Icon buttons: Square, minimal
- Use Heroicons via CDN

**Dropdowns:**
- Status: Todo, In Progress, Complete (or similar)
- Priority: Low, Medium, High, Critical

**Date Pickers:**
- Native HTML5 date inputs for simplicity
- Display formatted dates in table

## Interaction Patterns

**Drag and Drop:**
- Use native HTML5 drag/drop or react-beautiful-dnd library
- 200ms delay before drag starts (prevents accidental drags)
- Smooth animations (150ms easing)
- Clear drop indicators

**Empty States:**
- "No projects yet" with Create Project CTA
- "No tasks in this section" with subtle add task prompt
- Icons from Heroicons library

**Loading States:**
- Skeleton rows for table loading
- Spinner for async operations

## Accessibility & Patterns

- Keyboard navigation: Tab through interactive elements, Arrow keys in table
- Screen reader labels for drag handles
- Focus visible states on all interactive elements
- ARIA labels for icon buttons
- Semantic HTML: proper table structure, button elements

## Performance Considerations

- Virtual scrolling if tasks exceed 100 rows
- Debounced inline editing (500ms)
- Optimistic UI updates for drag operations

---

**No Images Required:** This is a data-focused application without hero sections or marketing content.