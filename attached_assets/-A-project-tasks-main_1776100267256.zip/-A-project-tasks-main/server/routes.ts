import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProjectSchema, insertSectionSchema, insertTaskSchema, taskStatusEnum, taskPriorityEnum, insertStatusReportSchema, statusReportStatusEnum, insertTeamMemberSchema } from "@shared/schema";
import { z } from "zod";

const updateTaskSchema = z.object({
  name: z.string().min(1).optional(),
  description: z.string().optional().nullable(),
  status: taskStatusEnum.optional().nullable(),
  priority: taskPriorityEnum.optional().nullable(),
  startDate: z.string().optional().nullable(),
  dueDate: z.string().optional().nullable(),
  assignedMemberId: z.string().optional().nullable(),
  sectionId: z.string().optional(),
  order: z.number().optional(),
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Projects
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  app.get("/api/projects/task-counts", async (req, res) => {
    try {
      const counts = await storage.getProjectTaskCounts();
      res.json(counts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch task counts" });
    }
  });

  app.get("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const data = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(data);
      // Automatically create a default "Tasks" section
      await storage.createSection({ name: "Tasks", projectId: project.id });
      // Log activity
      await storage.createActivityLog({
        entityType: "project",
        entityId: project.id,
        projectId: project.id,
        action: "created",
        timestamp: new Date().toISOString(),
      });
      res.status(201).json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const data = insertProjectSchema.partial().parse(req.body);
      const oldProject = await storage.getProject(req.params.id);
      if (!oldProject) {
        return res.status(404).json({ error: "Project not found" });
      }
      const project = await storage.updateProject(req.params.id, data);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      // Log field changes
      const timestamp = new Date().toISOString();
      for (const key of Object.keys(data) as Array<keyof typeof data>) {
        const oldVal = oldProject[key as keyof typeof oldProject];
        const newVal = data[key];
        if (oldVal !== newVal) {
          await storage.createActivityLog({
            entityType: "project",
            entityId: project.id,
            projectId: project.id,
            action: "updated",
            field: key,
            oldValue: oldVal != null ? String(oldVal) : null,
            newValue: newVal != null ? String(newVal) : null,
            timestamp,
          });
        }
      }
      res.json(project);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update project" });
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      const project = await storage.getProject(req.params.id);
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      // Log deletion before deleting
      await storage.createActivityLog({
        entityType: "project",
        entityId: req.params.id,
        projectId: req.params.id,
        action: "deleted",
        timestamp: new Date().toISOString(),
      });
      await storage.deleteProject(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete project" });
    }
  });

  // Sections
  app.get("/api/projects/:projectId/sections", async (req, res) => {
    try {
      const sections = await storage.getSectionsWithTasks(req.params.projectId);
      res.json(sections);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sections" });
    }
  });

  app.post("/api/projects/:projectId/sections", async (req, res) => {
    try {
      const data = insertSectionSchema.omit({ projectId: true, order: true }).parse(req.body);
      const section = await storage.createSection({
        ...data,
        projectId: req.params.projectId,
        order: 0,
      });
      // Log activity
      await storage.createActivityLog({
        entityType: "section",
        entityId: section.id,
        projectId: req.params.projectId,
        action: "created",
        field: "name",
        newValue: section.name,
        timestamp: new Date().toISOString(),
      });
      res.status(201).json(section);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create section" });
    }
  });

  app.patch("/api/sections/:id", async (req, res) => {
    try {
      const data = insertSectionSchema.partial().parse(req.body);
      const oldSection = await storage.getSection(req.params.id);
      if (!oldSection) {
        return res.status(404).json({ error: "Section not found" });
      }
      const section = await storage.updateSection(req.params.id, data);
      if (!section) {
        return res.status(404).json({ error: "Section not found" });
      }
      // Log field changes
      const timestamp = new Date().toISOString();
      for (const key of Object.keys(data) as Array<keyof typeof data>) {
        const oldVal = oldSection[key as keyof typeof oldSection];
        const newVal = data[key];
        if (oldVal !== newVal) {
          await storage.createActivityLog({
            entityType: "section",
            entityId: section.id,
            projectId: section.projectId,
            action: "updated",
            field: key,
            oldValue: oldVal != null ? String(oldVal) : null,
            newValue: newVal != null ? String(newVal) : null,
            timestamp,
          });
        }
      }
      res.json(section);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update section" });
    }
  });

  app.delete("/api/sections/:id", async (req, res) => {
    try {
      const section = await storage.getSection(req.params.id);
      if (!section) {
        return res.status(404).json({ error: "Section not found" });
      }
      // Log deletion before deleting
      await storage.createActivityLog({
        entityType: "section",
        entityId: req.params.id,
        projectId: section.projectId,
        action: "deleted",
        field: "name",
        oldValue: section.name,
        timestamp: new Date().toISOString(),
      });
      await storage.deleteSection(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete section" });
    }
  });

  app.post("/api/projects/:projectId/sections/reorder", async (req, res) => {
    try {
      const { sectionIds } = req.body;
      if (!Array.isArray(sectionIds)) {
        return res.status(400).json({ error: "sectionIds must be an array" });
      }
      await storage.reorderSections(req.params.projectId, sectionIds);
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to reorder sections" });
    }
  });

  // Tasks
  app.get("/api/tasks/:id", async (req, res) => {
    try {
      const task = await storage.getTask(req.params.id);
      if (!task) {
        return res.status(404).json({ error: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch task" });
    }
  });

  app.get("/api/projects/:projectId/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasks(req.params.projectId);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch tasks" });
    }
  });

  app.post("/api/projects/:projectId/tasks", async (req, res) => {
    try {
      const data = insertTaskSchema.omit({ projectId: true, order: true }).parse(req.body);
      const task = await storage.createTask({
        ...data,
        projectId: req.params.projectId,
        order: 0,
      });
      // Log activity
      await storage.createActivityLog({
        entityType: "task",
        entityId: task.id,
        projectId: req.params.projectId,
        action: "created",
        timestamp: new Date().toISOString(),
      });
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create task" });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const data = updateTaskSchema.parse(req.body);
      const oldTask = await storage.getTask(req.params.id);
      if (!oldTask) {
        return res.status(404).json({ error: "Task not found" });
      }
      const task = await storage.updateTask(req.params.id, data);
      if (!task) {
        return res.status(404).json({ error: "Task not found" });
      }
      // Log field changes (excluding order changes for drag-drop)
      const timestamp = new Date().toISOString();
      const fieldsToLog = ['name', 'description', 'status', 'priority', 'startDate', 'dueDate', 'assignedMemberId'] as const;
      for (const key of fieldsToLog) {
        if (data[key] !== undefined) {
          const oldVal = oldTask[key];
          const newVal = data[key];
          if (oldVal !== newVal) {
            await storage.createActivityLog({
              entityType: "task",
              entityId: task.id,
              projectId: task.projectId,
              action: "updated",
              field: key,
              oldValue: oldVal != null ? String(oldVal) : null,
              newValue: newVal != null ? String(newVal) : null,
              timestamp,
            });
          }
        }
      }
      res.json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const task = await storage.getTask(req.params.id);
      if (!task) {
        return res.status(404).json({ error: "Task not found" });
      }
      // Log deletion before deleting
      await storage.createActivityLog({
        entityType: "task",
        entityId: req.params.id,
        projectId: task.projectId,
        action: "deleted",
        timestamp: new Date().toISOString(),
      });
      await storage.deleteTask(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete task" });
    }
  });

  app.post("/api/sections/:sectionId/tasks/reorder", async (req, res) => {
    try {
      const { taskIds } = req.body;
      if (!Array.isArray(taskIds)) {
        return res.status(400).json({ error: "taskIds must be an array" });
      }
      await storage.reorderTasks(req.params.sectionId, taskIds);
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to reorder tasks" });
    }
  });

  app.post("/api/tasks/:taskId/move", async (req, res) => {
    try {
      const { fromSectionId, toSectionId, newOrder } = req.body;
      if (!fromSectionId || !toSectionId || typeof newOrder !== "number") {
        return res.status(400).json({ error: "Invalid move parameters" });
      }
      await storage.moveTask(req.params.taskId, fromSectionId, toSectionId, newOrder);
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to move task" });
    }
  });

  // Status Reports
  app.get("/api/projects/:projectId/status-reports", async (req, res) => {
    try {
      const reports = await storage.getStatusReports(req.params.projectId);
      res.json(reports);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch status reports" });
    }
  });

  app.get("/api/status-reports/:id", async (req, res) => {
    try {
      const report = await storage.getStatusReport(req.params.id);
      if (!report) {
        return res.status(404).json({ error: "Status report not found" });
      }
      res.json(report);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch status report" });
    }
  });

  app.post("/api/projects/:projectId/status-reports", async (req, res) => {
    try {
      const data = insertStatusReportSchema.omit({ projectId: true, createdAt: true }).parse(req.body);
      const report = await storage.createStatusReport({
        ...data,
        projectId: req.params.projectId,
        createdAt: new Date().toISOString(),
      });
      res.status(201).json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create status report" });
    }
  });

  app.patch("/api/status-reports/:id", async (req, res) => {
    try {
      const data = z.object({
        title: z.string().min(1).optional(),
        status: statusReportStatusEnum.optional(),
      }).parse(req.body);
      const report = await storage.updateStatusReport(req.params.id, data);
      if (!report) {
        return res.status(404).json({ error: "Status report not found" });
      }
      res.json(report);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update status report" });
    }
  });

  app.delete("/api/status-reports/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteStatusReport(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Status report not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete status report" });
    }
  });

  // Team Members
  app.get("/api/team-members", async (req, res) => {
    try {
      const members = await storage.getTeamMembers();
      res.json(members);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch team members" });
    }
  });

  app.post("/api/team-members", async (req, res) => {
    try {
      const data = insertTeamMemberSchema.parse(req.body);
      const member = await storage.createTeamMember(data);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create team member" });
    }
  });

  app.patch("/api/team-members/:id", async (req, res) => {
    try {
      const data = insertTeamMemberSchema.partial().parse(req.body);
      const member = await storage.updateTeamMember(req.params.id, data);
      if (!member) {
        return res.status(404).json({ error: "Team member not found" });
      }
      res.json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to update team member" });
    }
  });

  app.delete("/api/team-members/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteTeamMember(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Team member not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete team member" });
    }
  });

  // Project Members
  app.get("/api/projects/:projectId/members", async (req, res) => {
    try {
      const members = await storage.getProjectMembers(req.params.projectId);
      res.json(members);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project members" });
    }
  });

  app.post("/api/projects/:projectId/members", async (req, res) => {
    try {
      const { memberId } = req.body;
      if (!memberId) {
        return res.status(400).json({ error: "memberId is required" });
      }
      const member = await storage.getTeamMember(memberId);
      if (!member) {
        return res.status(404).json({ error: "Team member not found" });
      }
      const pm = await storage.addProjectMember(req.params.projectId, memberId);
      res.status(201).json(pm);
    } catch (error) {
      res.status(500).json({ error: "Failed to add project member" });
    }
  });

  app.delete("/api/projects/:projectId/members/:memberId", async (req, res) => {
    try {
      const removed = await storage.removeProjectMember(req.params.projectId, req.params.memberId);
      if (!removed) {
        return res.status(404).json({ error: "Project member not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to remove project member" });
    }
  });

  // Activity Logs
  app.get("/api/projects/:projectId/activity", async (req, res) => {
    try {
      const logs = await storage.getActivityLogs(req.params.projectId);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activity logs" });
    }
  });

  return httpServer;
}
