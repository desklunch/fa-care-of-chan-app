import {
  type User,
  type InsertUser,
  type Project,
  type InsertProject,
  type Section,
  type InsertSection,
  type Task,
  type InsertTask,
  type SectionWithTasks,
  type StatusReport,
  type InsertStatusReport,
  type TeamMember,
  type InsertTeamMember,
  type ProjectMember,
  type InsertProjectMember,
  type ActivityLog,
  type InsertActivityLog,
  type ActivityLogWithPerformer,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getProjects(): Promise<Project[]>;
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;
  getProjectTaskCounts(): Promise<Record<string, number>>;

  getSections(projectId: string): Promise<Section[]>;
  getSection(id: string): Promise<Section | undefined>;
  createSection(section: InsertSection): Promise<Section>;
  updateSection(id: string, section: Partial<InsertSection>): Promise<Section | undefined>;
  deleteSection(id: string): Promise<boolean>;
  reorderSections(projectId: string, sectionIds: string[]): Promise<void>;
  getSectionsWithTasks(projectId: string): Promise<SectionWithTasks[]>;

  getTasks(projectId: string): Promise<Task[]>;
  getTasksBySection(sectionId: string): Promise<Task[]>;
  getTask(id: string): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: string): Promise<boolean>;
  reorderTasks(sectionId: string, taskIds: string[]): Promise<void>;
  moveTask(taskId: string, fromSectionId: string, toSectionId: string, newOrder: number): Promise<void>;

  getStatusReports(projectId: string): Promise<StatusReport[]>;
  getStatusReport(id: string): Promise<StatusReport | undefined>;
  createStatusReport(report: InsertStatusReport): Promise<StatusReport>;
  updateStatusReport(id: string, report: Partial<InsertStatusReport>): Promise<StatusReport | undefined>;
  deleteStatusReport(id: string): Promise<boolean>;

  getTeamMembers(): Promise<TeamMember[]>;
  getTeamMember(id: string): Promise<TeamMember | undefined>;
  createTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  updateTeamMember(id: string, member: Partial<InsertTeamMember>): Promise<TeamMember | undefined>;
  deleteTeamMember(id: string): Promise<boolean>;

  getProjectMembers(projectId: string): Promise<TeamMember[]>;
  addProjectMember(projectId: string, memberId: string): Promise<ProjectMember>;
  removeProjectMember(projectId: string, memberId: string): Promise<boolean>;
  isProjectMember(projectId: string, memberId: string): Promise<boolean>;

  getActivityLogs(projectId: string): Promise<ActivityLogWithPerformer[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private projects: Map<string, Project>;
  private sections: Map<string, Section>;
  private tasks: Map<string, Task>;
  private statusReports: Map<string, StatusReport>;
  private teamMembers: Map<string, TeamMember>;
  private projectMembers: Map<string, ProjectMember>;
  private activityLogs: Map<string, ActivityLog>;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.sections = new Map();
    this.tasks = new Map();
    this.statusReports = new Map();
    this.teamMembers = new Map();
    this.projectMembers = new Map();
    this.activityLogs = new Map();
    this.seedTestData();
  }

  private seedTestData() {
    // Create 5 team members
    const member1Id = randomUUID();
    const member1: TeamMember = { id: member1Id, name: "Alice Johnson", email: "alice@example.com" };
    this.teamMembers.set(member1Id, member1);

    const member2Id = randomUUID();
    const member2: TeamMember = { id: member2Id, name: "Bob Smith", email: "bob@example.com" };
    this.teamMembers.set(member2Id, member2);

    const member3Id = randomUUID();
    const member3: TeamMember = { id: member3Id, name: "Carol Williams", email: "carol@example.com" };
    this.teamMembers.set(member3Id, member3);

    const member4Id = randomUUID();
    const member4: TeamMember = { id: member4Id, name: "David Brown", email: "david@example.com" };
    this.teamMembers.set(member4Id, member4);

    const member5Id = randomUUID();
    const member5: TeamMember = { id: member5Id, name: "Emma Davis", email: "emma@example.com" };
    this.teamMembers.set(member5Id, member5);

    // Create project 1 (created by Alice)
    const project1Id = randomUUID();
    const project1: Project = {
      id: project1Id,
      name: "Website Redesign",
      description: "Complete redesign of the company website with modern UI/UX",
      createdById: member1Id,
    };
    this.projects.set(project1Id, project1);

    // Add 4 members to project 1 (Alice, Bob, Carol, David - not Emma)
    const pm1Id = randomUUID();
    this.projectMembers.set(pm1Id, { id: pm1Id, projectId: project1Id, memberId: member1Id });
    const pm2Id = randomUUID();
    this.projectMembers.set(pm2Id, { id: pm2Id, projectId: project1Id, memberId: member2Id });
    const pm3Id = randomUUID();
    this.projectMembers.set(pm3Id, { id: pm3Id, projectId: project1Id, memberId: member3Id });
    const pm4Id = randomUUID();
    this.projectMembers.set(pm4Id, { id: pm4Id, projectId: project1Id, memberId: member4Id });

    // Use the 4 project members for task assignment (rotate through them)
    const projectMemberIds = [member1Id, member2Id, member3Id, member4Id];
    let taskCounter = 0;

    const sectionData = [
      { name: "Planning", tasks: ["Define requirements", "Create wireframes", "Stakeholder review"] },
      { name: "Design", tasks: ["Design homepage", "Design product pages", "Create style guide"] },
      { name: "Development", tasks: ["Set up project", "Implement frontend", "Backend integration"] },
    ];

    sectionData.forEach((sectionInfo, sectionIndex) => {
      const sectionId = randomUUID();
      const section: Section = {
        id: sectionId,
        projectId: project1Id,
        name: sectionInfo.name,
        order: sectionIndex,
      };
      this.sections.set(sectionId, section);

      sectionInfo.tasks.forEach((taskName, taskIndex) => {
        const taskId = randomUUID();
        const task: Task = {
          id: taskId,
          sectionId: sectionId,
          projectId: project1Id,
          name: taskName,
          status: taskIndex === 0 ? "complete" : taskIndex === 1 ? "in_progress" : "todo",
          priority: taskIndex === 2 ? "high" : "medium",
          startDate: null,
          dueDate: null,
          description: null,
          assignedMemberId: projectMemberIds[taskCounter % projectMemberIds.length],
          createdById: member1Id,
          order: taskIndex,
        };
        this.tasks.set(taskId, task);
        taskCounter++;
      });
    });

    const project2Id = randomUUID();
    const project2: Project = {
      id: project2Id,
      name: "Empty Project",
      description: "A new project ready for planning",
      createdById: null,
    };
    this.projects.set(project2Id, project2);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = { 
      id,
      name: insertProject.name,
      description: insertProject.description ?? null,
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(
    id: string,
    update: Partial<InsertProject>
  ): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    const updated = { ...project, ...update };
    this.projects.set(id, updated);
    return updated;
  }

  async deleteProject(id: string): Promise<boolean> {
    const sections = await this.getSections(id);
    for (const section of sections) {
      await this.deleteSection(section.id);
    }
    return this.projects.delete(id);
  }

  async getProjectTaskCounts(): Promise<Record<string, number>> {
    const counts: Record<string, number> = {};
    const tasks = Array.from(this.tasks.values());
    for (const task of tasks) {
      counts[task.projectId] = (counts[task.projectId] || 0) + 1;
    }
    return counts;
  }

  async getSections(projectId: string): Promise<Section[]> {
    return Array.from(this.sections.values())
      .filter((s) => s.projectId === projectId)
      .sort((a, b) => a.order - b.order);
  }

  async getSection(id: string): Promise<Section | undefined> {
    return this.sections.get(id);
  }

  async createSection(insertSection: InsertSection): Promise<Section> {
    const id = randomUUID();
    const existingSections = await this.getSections(insertSection.projectId);
    const maxOrder = existingSections.length > 0 
      ? Math.max(...existingSections.map((s) => s.order)) + 1 
      : 0;
    const section: Section = { 
      ...insertSection, 
      id, 
      order: insertSection.order ?? maxOrder 
    };
    this.sections.set(id, section);
    return section;
  }

  async updateSection(
    id: string,
    update: Partial<InsertSection>
  ): Promise<Section | undefined> {
    const section = this.sections.get(id);
    if (!section) return undefined;
    const updated = { ...section, ...update };
    this.sections.set(id, updated);
    return updated;
  }

  async deleteSection(id: string): Promise<boolean> {
    const tasks = await this.getTasksBySection(id);
    for (const task of tasks) {
      this.tasks.delete(task.id);
    }
    return this.sections.delete(id);
  }

  async reorderSections(projectId: string, sectionIds: string[]): Promise<void> {
    sectionIds.forEach((id, index) => {
      const section = this.sections.get(id);
      if (section && section.projectId === projectId) {
        this.sections.set(id, { ...section, order: index });
      }
    });
  }

  async getSectionsWithTasks(projectId: string): Promise<SectionWithTasks[]> {
    const sections = await this.getSections(projectId);
    const result: SectionWithTasks[] = [];
    for (const section of sections) {
      const tasks = await this.getTasksBySection(section.id);
      result.push({ ...section, tasks: tasks.sort((a, b) => a.order - b.order) });
    }
    return result;
  }

  async getTasks(projectId: string): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter((t) => t.projectId === projectId)
      .sort((a, b) => a.order - b.order);
  }

  async getTasksBySection(sectionId: string): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter((t) => t.sectionId === sectionId)
      .sort((a, b) => a.order - b.order);
  }

  async getTask(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = randomUUID();
    const existingTasks = await this.getTasksBySection(insertTask.sectionId);
    const maxOrder = existingTasks.length > 0 
      ? Math.max(...existingTasks.map((t) => t.order)) + 1 
      : 0;
    const task: Task = { 
      id,
      name: insertTask.name,
      description: insertTask.description ?? null,
      status: (insertTask.status as Task["status"]) ?? null,
      priority: (insertTask.priority as Task["priority"]) ?? null,
      startDate: insertTask.startDate ?? null,
      dueDate: insertTask.dueDate ?? null,
      assignedMemberId: insertTask.assignedMemberId ?? null,
      sectionId: insertTask.sectionId,
      projectId: insertTask.projectId,
      order: insertTask.order ?? maxOrder,
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(
    id: string,
    update: Partial<InsertTask>
  ): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    const updated: Task = {
      ...task,
      name: update.name ?? task.name,
      description: update.description !== undefined ? update.description ?? null : task.description,
      status: update.status !== undefined ? (update.status as Task["status"]) ?? null : task.status,
      priority: update.priority !== undefined ? (update.priority as Task["priority"]) ?? null : task.priority,
      startDate: update.startDate !== undefined ? update.startDate ?? null : task.startDate,
      dueDate: update.dueDate !== undefined ? update.dueDate ?? null : task.dueDate,
      assignedMemberId: update.assignedMemberId !== undefined ? update.assignedMemberId ?? null : task.assignedMemberId,
      sectionId: update.sectionId ?? task.sectionId,
      projectId: update.projectId ?? task.projectId,
      order: update.order ?? task.order,
    };
    this.tasks.set(id, updated);
    return updated;
  }

  async deleteTask(id: string): Promise<boolean> {
    return this.tasks.delete(id);
  }

  async reorderTasks(sectionId: string, taskIds: string[]): Promise<void> {
    taskIds.forEach((id, index) => {
      const task = this.tasks.get(id);
      if (task && task.sectionId === sectionId) {
        this.tasks.set(id, { ...task, order: index });
      }
    });
  }

  async moveTask(
    taskId: string,
    fromSectionId: string,
    toSectionId: string,
    newOrder: number
  ): Promise<void> {
    const task = this.tasks.get(taskId);
    if (!task) return;

    // If moving within the same section, just reorder
    if (fromSectionId === toSectionId) {
      const sectionTasks = await this.getTasksBySection(fromSectionId);
      const oldIndex = sectionTasks.findIndex(t => t.id === taskId);
      
      sectionTasks.forEach((t, index) => {
        let newTaskOrder = index;
        if (t.id === taskId) {
          newTaskOrder = newOrder;
        } else if (oldIndex < newOrder) {
          // Moving down: shift tasks between old and new position up
          if (index > oldIndex && index <= newOrder) {
            newTaskOrder = index - 1;
          }
        } else {
          // Moving up: shift tasks between new and old position down
          if (index >= newOrder && index < oldIndex) {
            newTaskOrder = index + 1;
          }
        }
        this.tasks.set(t.id, { ...t, order: newTaskOrder });
      });
      return;
    }

    // Moving to different section
    // Remove from source section and normalize order
    const sourceTasks = await this.getTasksBySection(fromSectionId);
    const filteredSourceTasks = sourceTasks.filter(t => t.id !== taskId);
    filteredSourceTasks.forEach((t, index) => {
      this.tasks.set(t.id, { ...t, order: index });
    });

    // Insert into target section at the specified position
    const targetTasks = await this.getTasksBySection(toSectionId);
    targetTasks.forEach((t, index) => {
      if (index >= newOrder) {
        this.tasks.set(t.id, { ...t, order: index + 1 });
      }
    });

    // Update the moved task
    this.tasks.set(taskId, {
      ...task,
      sectionId: toSectionId,
      order: newOrder,
    });
  }

  async getStatusReports(projectId: string): Promise<StatusReport[]> {
    return Array.from(this.statusReports.values())
      .filter((r) => r.projectId === projectId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getStatusReport(id: string): Promise<StatusReport | undefined> {
    return this.statusReports.get(id);
  }

  async createStatusReport(insertReport: InsertStatusReport): Promise<StatusReport> {
    const id = randomUUID();
    const report: StatusReport = {
      id,
      title: insertReport.title,
      status: insertReport.status as StatusReport["status"],
      projectId: insertReport.projectId,
      createdAt: insertReport.createdAt,
    };
    this.statusReports.set(id, report);
    return report;
  }

  async updateStatusReport(
    id: string,
    update: Partial<InsertStatusReport>
  ): Promise<StatusReport | undefined> {
    const report = this.statusReports.get(id);
    if (!report) return undefined;
    const updated: StatusReport = {
      ...report,
      title: update.title ?? report.title,
      status: (update.status as StatusReport["status"]) ?? report.status,
    };
    this.statusReports.set(id, updated);
    return updated;
  }

  async deleteStatusReport(id: string): Promise<boolean> {
    return this.statusReports.delete(id);
  }

  async getTeamMembers(): Promise<TeamMember[]> {
    return Array.from(this.teamMembers.values()).sort((a, b) => a.name.localeCompare(b.name));
  }

  async getTeamMember(id: string): Promise<TeamMember | undefined> {
    return this.teamMembers.get(id);
  }

  async createTeamMember(insertMember: InsertTeamMember): Promise<TeamMember> {
    const id = randomUUID();
    const member: TeamMember = {
      id,
      name: insertMember.name,
      email: insertMember.email ?? null,
    };
    this.teamMembers.set(id, member);
    return member;
  }

  async updateTeamMember(id: string, update: Partial<InsertTeamMember>): Promise<TeamMember | undefined> {
    const member = this.teamMembers.get(id);
    if (!member) return undefined;
    const updated: TeamMember = {
      ...member,
      name: update.name ?? member.name,
      email: update.email !== undefined ? update.email ?? null : member.email,
    };
    this.teamMembers.set(id, updated);
    return updated;
  }

  async deleteTeamMember(id: string): Promise<boolean> {
    // Remove from all project memberships
    const memberships = Array.from(this.projectMembers.values()).filter(pm => pm.memberId === id);
    for (const pm of memberships) {
      this.projectMembers.delete(pm.id);
    }
    // Unassign from all tasks
    const tasks = Array.from(this.tasks.values()).filter(t => t.assignedMemberId === id);
    for (const task of tasks) {
      this.tasks.set(task.id, { ...task, assignedMemberId: null });
    }
    return this.teamMembers.delete(id);
  }

  async getProjectMembers(projectId: string): Promise<TeamMember[]> {
    const memberIds = Array.from(this.projectMembers.values())
      .filter(pm => pm.projectId === projectId)
      .map(pm => pm.memberId);
    const members = memberIds
      .map(id => this.teamMembers.get(id))
      .filter((m): m is TeamMember => m !== undefined);
    return members.sort((a, b) => a.name.localeCompare(b.name));
  }

  async addProjectMember(projectId: string, memberId: string): Promise<ProjectMember> {
    // Check if already a member
    const existing = Array.from(this.projectMembers.values()).find(
      pm => pm.projectId === projectId && pm.memberId === memberId
    );
    if (existing) return existing;
    
    const id = randomUUID();
    const pm: ProjectMember = { id, projectId, memberId };
    this.projectMembers.set(id, pm);
    return pm;
  }

  async removeProjectMember(projectId: string, memberId: string): Promise<boolean> {
    const pm = Array.from(this.projectMembers.values()).find(
      pm => pm.projectId === projectId && pm.memberId === memberId
    );
    if (!pm) return false;
    
    // Unassign this member from all tasks in this project
    const tasks = Array.from(this.tasks.values()).filter(
      t => t.projectId === projectId && t.assignedMemberId === memberId
    );
    for (const task of tasks) {
      this.tasks.set(task.id, { ...task, assignedMemberId: null });
    }
    
    return this.projectMembers.delete(pm.id);
  }

  async isProjectMember(projectId: string, memberId: string): Promise<boolean> {
    return Array.from(this.projectMembers.values()).some(
      pm => pm.projectId === projectId && pm.memberId === memberId
    );
  }

  async getActivityLogs(projectId: string): Promise<ActivityLogWithPerformer[]> {
    const logs = Array.from(this.activityLogs.values())
      .filter((log) => log.projectId === projectId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    return logs.map((log) => {
      const performer = log.performedById ? this.teamMembers.get(log.performedById) : undefined;
      return {
        ...log,
        performerName: performer?.name,
      };
    });
  }

  async createActivityLog(insertLog: InsertActivityLog): Promise<ActivityLog> {
    const id = randomUUID();
    const log: ActivityLog = {
      id,
      entityType: insertLog.entityType,
      entityId: insertLog.entityId,
      projectId: insertLog.projectId,
      action: insertLog.action,
      field: insertLog.field ?? null,
      oldValue: insertLog.oldValue ?? null,
      newValue: insertLog.newValue ?? null,
      performedById: insertLog.performedById ?? null,
      timestamp: insertLog.timestamp,
    };
    this.activityLogs.set(id, log);
    return log;
  }
}

export const storage = new MemStorage();
